package app.thinktwice

import app.thinktwice.core.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class RuleEngineTest {
    private val madrid = ZoneId.of("Europe/Madrid")
    private fun at(s: String, z: ZoneId = madrid) = LocalDateTime.parse(s).atZone(z).toInstant().toEpochMilli()
    private val ig = "com.instagram.android"

    // 2026-11-16 es lunes.
    private val night = Routine("n", "Noche", setOf(ig), 23 * 60, 7 * 60, setOf(1), true)

    @Test fun nightRoutineCrossesMidnight() {
        val s = AppState(routines = listOf(night))
        assertTrue(RuleEngine.decide(s, ig, at("2026-11-16T23:30"), madrid) is Decision.Block)
        // Martes 03:00 sigue vigente la franja que empezó el lunes.
        val d = RuleEngine.decide(s, ig, at("2026-11-17T03:00"), madrid)
        assertTrue(d is Decision.Block)
        assertEquals(at("2026-11-17T07:00"), (d as Decision.Block).untilMs)
        // Martes 23:30: el martes no está en los días.
        assertEquals(Decision.Allow, RuleEngine.decide(s, ig, at("2026-11-17T23:30"), madrid))
        assertEquals(Decision.Allow, RuleEngine.decide(s, ig, at("2026-11-17T07:00"), madrid))
    }

    @Test fun overlappingRestrictionsChain() {
        val a = Routine("a", "A", setOf(ig), 9 * 60, 10 * 60, (1..7).toSet(), true)
        val b = Routine("b", "B", setOf(ig), 9 * 60 + 50, 12 * 60, (1..7).toSet(), true)
        val s = AppState(routines = listOf(a, b))
        val d = RuleEngine.decide(s, ig, at("2026-11-16T09:10"), madrid) as Decision.Block
        assertEquals(at("2026-11-16T12:00"), d.untilMs)
        // Cuando termina A, B sigue: no se libera.
        assertTrue(RuleEngine.decide(s, ig, at("2026-11-16T10:00"), madrid) is Decision.Block)
    }

    @Test fun sessionEndsButRoutineContinues() {
        val r = Routine("r", "R", setOf(ig), 10 * 60, 12 * 60, (1..7).toSet(), true)
        val sess = BlockSession("s", "Foco", setOf(ig), at("2026-11-16T09:00"), at("2026-11-16T10:30"))
        val s = AppState(routines = listOf(r), sessions = listOf(sess))
        val d = RuleEngine.decide(s, ig, at("2026-11-16T09:30"), madrid) as Decision.Block
        assertEquals(at("2026-11-16T12:00"), d.untilMs)
        assertTrue(RuleEngine.decide(s, ig, at("2026-11-16T11:00"), madrid) is Decision.Block)
    }

    @Test fun emergencySkipReleasesOnlyThatRoutine() {
        val r = Routine("r", "R", setOf(ig), 10 * 60, 12 * 60, (1..7).toSet(), true)
        val s = AppState(routines = listOf(r), routineSkips = mapOf("r" to at("2026-11-16T12:00")))
        assertEquals(Decision.Allow, RuleEngine.decide(s, ig, at("2026-11-16T11:00"), madrid))
        // Al día siguiente la rutina vuelve a aplicarse.
        assertTrue(RuleEngine.decide(s, ig, at("2026-11-17T11:00"), madrid) is Decision.Block)
    }

    @Test fun pauseAndAllowance() {
        val now = at("2026-11-16T15:00")
        val s = AppState(pausedApps = setOf(ig))
        assertEquals(Decision.Pause(ig), RuleEngine.decide(s, ig, now, madrid))
        val allowed = s.copy(allowances = mapOf(ig to now + 5 * 60_000))
        assertEquals(Decision.Allow, RuleEngine.decide(allowed, ig, now + 60_000, madrid))
        assertEquals(Decision.Pause(ig), RuleEngine.decide(allowed, ig, now + 5 * 60_000, madrid))
    }

    @Test fun blockWinsOverPause() {
        val now = at("2026-11-16T15:00")
        val sess = BlockSession("s", "Foco", setOf(ig), now - 1, now + 60_000)
        val s = AppState(pausedApps = setOf(ig), sessions = listOf(sess), allowances = mapOf(ig to now + 999_999))
        assertTrue(RuleEngine.decide(s, ig, now, madrid) is Decision.Block)
    }

    @Test fun timezoneChangeUsesLocalWallClock() {
        val r = Routine("r", "R", setOf(ig), 22 * 60, 23 * 60, (1..7).toSet(), true)
        val s = AppState(routines = listOf(r))
        val ny = ZoneId.of("America/New_York")
        assertTrue(RuleEngine.decide(s, ig, at("2026-11-16T22:30", ny), ny) is Decision.Block)
        assertEquals(Decision.Allow, RuleEngine.decide(s, ig, at("2026-11-16T22:30", ny), madrid))
    }

    @Test fun dstNightIsHandled() {
        // 2026-03-29: en Madrid se adelanta la hora (02:00 → 03:00). Domingo = 7.
        val r = Routine("r", "R", setOf(ig), 1 * 60, 4 * 60, setOf(7), true)
        val s = AppState(routines = listOf(r))
        val d = RuleEngine.decide(s, ig, at("2026-03-29T03:30"), madrid) as Decision.Block
        assertEquals(at("2026-03-29T04:00"), d.untilMs)
    }

    @Test fun productivityFormula() {
        val classes = mapOf("u" to AppClass.USEFUL, "d" to AppClass.DISTRACTING, "n" to AppClass.NEUTRAL)
        assertEquals(75, Productivity.percent(mapOf("u" to 30L, "d" to 10L, "n" to 500L, "x" to 99L), classes))
        assertNull(Productivity.percent(mapOf("n" to 10L), classes))
        // Semanal: tiempos acumulados, no media de porcentajes (media sería 50).
        val week = listOf(mapOf("u" to 90L, "d" to 10L), mapOf("u" to 0L, "d" to 100L))
        assertEquals(45, Productivity.percentAggregated(week, classes))
    }

    @Test fun nextRoutine() {
        val s = AppState(routines = listOf(night))
        val n = RuleEngine.nextRoutineStart(s, at("2026-11-17T12:00"), madrid)!!
        assertEquals(at("2026-11-23T23:00"), n.second.first)
    }

    @Test fun challengeStatuses() {
        val today = java.time.LocalDate.of(2026, 11, 18)
        val d1 = today.minusDays(2); val d2 = today.minusDays(1)
        val done = BlockSession("s", "F", setOf(ig), at("${d1}T10:00"), at("${d1}T11:00"))
        val early = BlockSession("e", "F", setOf(ig), at("${d2}T10:00"), at("${d2}T11:00"), endedEarlyAtMs = at("${d2}T10:10"))
        val c = Challenge("c", ChallengeKind.DAILY_SESSION, 7, d1.toEpochDay())
        val inputs = object : ChallengeInputs {
            override fun usage(day: java.time.LocalDate): DayUsage? = null
            override val state = AppState(sessions = listOf(done, early))
            override val zone: ZoneId = madrid
        }
        assertEquals(DayStatus.MET_MEASURED, Challenges.evaluate(c, d1, today, inputs))
        assertEquals(DayStatus.MISSED_MEASURED, Challenges.evaluate(c, d2, today, inputs))
        assertEquals(DayStatus.PENDING, Challenges.evaluate(c, today, today, inputs))
        assertEquals(DayStatus.PENDING, Challenges.evaluate(c, today.plusDays(1), today, inputs))
        val goal = Challenge("g", ChallengeKind.USAGE_GOAL, 7, d1.toEpochDay(), goalMinutes = 10, manual = mapOf(d2.toEpochDay() to true))
        assertEquals(DayStatus.NO_DATA, Challenges.evaluate(goal, d1, today, inputs))
        assertEquals(DayStatus.MET_MANUAL, Challenges.evaluate(goal, d2, today, inputs))
    }
}
