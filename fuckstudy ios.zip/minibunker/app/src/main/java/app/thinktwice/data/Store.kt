package app.thinktwice.data

import android.content.Context
import android.util.Log
import app.thinktwice.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Almacenamiento local único (un archivo JSON en el almacenamiento privado de la app).
 * La interfaz y el servicio de intervención comparten este objeto porque viven en el mismo
 * proceso. Las escrituras son atómicas (archivo temporal + renombrado) y se hacen en un hilo
 * propio; si una escritura falla, el estado en memoria se conserva y se reintenta en la siguiente.
 */
object Store {
    private const val FILE = "thinktwice-state.json"
    private val io = Executors.newSingleThreadExecutor()
    private val lock = Any()
    private lateinit var file: File
    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> get() = _state
    @Volatile var lastWriteError: String? = null; private set
    @Volatile private var ready = false

    fun init(context: Context) {
        if (ready) return
        synchronized(lock) {
            if (ready) return
            file = File(context.applicationContext.filesDir, FILE)
            if (file.exists()) {
                runCatching { _state.value = Codec.decode(file.readText()) }
                    .onFailure { Log.e("thinktwice", "Estado ilegible, se conserva copia", it); file.copyTo(File(file.path + ".corrupt"), true) }
            }
            ready = true
        }
    }

    fun update(transform: (AppState) -> AppState) {
        val snapshot: AppState
        synchronized(lock) {
            snapshot = prune(transform(_state.value))
            _state.value = snapshot
        }
        persist(snapshot)
    }

    fun replaceAll(newState: AppState) = update { newState }

    fun log(type: EventType, pkg: String? = null, ref: String? = null) =
        update { it.copy(events = it.events + LogEvent(System.currentTimeMillis(), type, pkg, ref)) }

    fun newId(): String = UUID.randomUUID().toString().take(8)

    private fun prune(s: AppState): AppState {
        val now = System.currentTimeMillis()
        val minT = now - Defaults.EVENT_RETENTION_DAYS * 86_400_000L
        val ev = s.events.filter { it.t >= minT }.takeLast(Defaults.MAX_EVENTS)
        val allow = s.allowances.filterValues { it > now }
        val skips = s.routineSkips.filterValues { it > now }
        return if (ev.size == s.events.size && allow.size == s.allowances.size && skips.size == s.routineSkips.size) s
        else s.copy(events = ev, allowances = allow, routineSkips = skips)
    }

    private fun persist(s: AppState) {
        if (!ready) return
        io.execute {
            try {
                val tmp = File(file.path + ".tmp")
                // Siempre se escribe el estado más reciente: las escrituras en cola no retroceden.
                tmp.writeText(Codec.encode(_state.value))
                if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
                lastWriteError = null
            } catch (e: Exception) {
                lastWriteError = e.message
                Log.e("thinktwice", "No se pudo guardar", e)
            }
        }
    }

    /** Borra todos los datos de la app (no toca permisos: esos se revocan en Ajustes del sistema). */
    fun wipe() = update { AppState() }
}
