package app.minibunker.ui.tt

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import app.minibunker.ui.Dest
import app.minibunker.ui.LocalNav
import app.minibunker.ui.LocalResumeTick
import app.minibunker.ui.SheetKind
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val es = Locale("es", "ES")

@Composable
fun Metric(value: String, label: String, modifier: Modifier) {
    Column(modifier) {
        Text(value, style = Type.cardFigure)
        Text(label, style = Type.label, maxLines = 2)
    }
}

@Composable
fun ActiveCard(
    name: String, kind: String, packages: Set<String>, remainingMs: Long, operative: Boolean,
    action: String? = null, onAction: (() -> Unit)? = null, onClick: (() -> Unit)? = null,
) {
    TTCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(kind, style = Type.label)
                Text(name, style = Type.cardTitle, maxLines = 1)
            }
            StatusDot(operative, if (operative) "Protección activa" else "No operativa")
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(Fmt.countdown(remainingMs), style = Type.cardFigure.copy(fontFeatureSettings = "tnum"))
                Text("restante · ${appsSummary(packages.size)}", style = Type.secondary)
            }
            AppStack(packages)
        }
        if (action != null && onAction != null) {
            Spacer(Modifier.height(14.dp))
            SmallPill(action, onAction, Icons.Rounded.Close, tone = ButtonTone.Danger)
        }
    }
}

fun routineIcon(key: String) = when (key) {
    "morning" -> Icons.Rounded.WbSunny
    "study" -> Icons.Rounded.School
    "work" -> Icons.Rounded.Work
    "sleep" -> Icons.Rounded.Bedtime
    "focus" -> Icons.Rounded.CenterFocusStrong
    else -> Icons.Rounded.EventRepeat
}
