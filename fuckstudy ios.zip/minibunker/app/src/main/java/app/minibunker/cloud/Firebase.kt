package app.minibunker.cloud

import app.minibunker.json.*
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Acceso REST a la MISMA cuenta de Firebase que usa la web de MIBUNKER (correo y contraseña,
 * Firestore en users/{uid}/data/{parte}). Sin SDK de Firebase: las mismas llamadas que hace el index.html.
 */
object FB {
    const val API_KEY = "AIzaSyDQBtfmym0ywn_vzMYdAygK0H0NAdq-xSc"
    const val PROJECT = "mibunker-8783e"
    const val DOCS = "projects/$PROJECT/databases/(default)/documents"
    const val FS = "https://firestore.googleapis.com/v1/$DOCS"
}

class NetworkException : IOException("Sin conexión a internet.")
class AuthException(val code: String, message: String) : Exception(message)
class RemoteException(val status: Int, message: String) : Exception(message)

data class Session(val uid: String, val email: String, val idToken: String, val refreshToken: String, val exp: Long, val name: String) {
    fun toJson(): JObj = linkedMapOf("uid" to uid, "email" to email, "idToken" to idToken, "refreshToken" to refreshToken, "exp" to exp, "name" to name)
    companion object {
        fun from(o: JObj?): Session? = o?.let {
            if (it.str("uid").isEmpty()) null
            else Session(it.str("uid"), it.str("email"), it.str("idToken"), it.str("refreshToken"), it.long("exp"), it.str("name"))
        }
    }
}

/** Petición HTTP mínima. Cualquier fallo de red se convierte en [NetworkException]. */
internal object Http {
    data class Resp(val code: Int, val body: String)

    fun call(method: String, url: String, body: String? = null, contentType: String = "application/json", token: String? = null): Resp {
        val c = try { URL(url).openConnection() as HttpURLConnection } catch (e: IOException) { throw NetworkException() }
        try {
            c.connectTimeout = 12_000; c.readTimeout = 20_000
            // Android (OkHttp) admite PATCH; si una implementación no lo admite, se usa POST con la
            // cabecera de sustitución que aceptan las API de Google.
            try { c.requestMethod = method } catch (e: java.net.ProtocolException) {
                c.requestMethod = "POST"; c.setRequestProperty("X-HTTP-Method-Override", method)
            }
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "$contentType; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            return Resp(code, text)
        } catch (e: IOException) {
            throw NetworkException()
        } finally { c.disconnect() }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

object FirebaseAuthRest {
    /** Mismos mensajes que la web de MIBUNKER. */
    private val ERR = mapOf(
        "EMAIL_EXISTS" to "Ya existe una cuenta con ese correo. Inicia sesión.",
        "EMAIL_NOT_FOUND" to "No hay ninguna cuenta con ese correo. Pulsa «Crear cuenta».",
        "INVALID_PASSWORD" to "Contraseña incorrecta.",
        "INVALID_LOGIN_CREDENTIALS" to "Correo o contraseña incorrectos.",
        "INVALID_EMAIL" to "Escribe un correo electrónico válido.",
        "WEAK_PASSWORD" to "La contraseña debe tener al menos 6 caracteres.",
        "TOO_MANY_ATTEMPTS_TRY_LATER" to "Demasiados intentos. Espera unos minutos y vuelve a probar.",
        "USER_DISABLED" to "Esta cuenta está desactivada.",
        "MISSING_PASSWORD" to "Escribe tu contraseña.",
        "CREDENTIAL_TOO_OLD_LOGIN_AGAIN" to "Por seguridad, cierra sesión, vuelve a entrar y repite la acción.",
        "TOKEN_EXPIRED" to "Tu sesión ha caducado. Vuelve a iniciar sesión.",
        "USER_NOT_FOUND" to "Esta cuenta ya no existe.",
    )

    private fun accounts(ep: String, body: JObj): JObj {
        val r = Http.call("POST", "https://identitytoolkit.googleapis.com/v1/accounts:$ep?key=${FB.API_KEY}", Json.write(body))
        val j = runCatching { Json.obj(r.body) }.getOrDefault(emptyMap())
        if (r.code !in 200..299) {
            val msg = j.objOrNull("error")?.str("message").orEmpty()
            val code = msg.split(" ")[0].split(":")[0]
            throw AuthException(code, ERR[code] ?: "No se pudo completar. Inténtalo de nuevo.")
        }
        return j
    }

    private fun sessionFrom(j: JObj, name: String) = Session(
        j.str("localId"), j.str("email"), j.str("idToken"), j.str("refreshToken"),
        System.currentTimeMillis() + (j.long("expiresIn", 3600)) * 1000 - 60_000, name.ifEmpty { j.str("displayName") },
    )

    fun signIn(email: String, password: String): Session =
        sessionFrom(accounts("signInWithPassword", mapOf("email" to email, "password" to password, "returnSecureToken" to true)), "")

    fun signUp(email: String, password: String, name: String): Session {
        val j = accounts("signUp", mapOf("email" to email, "password" to password, "returnSecureToken" to true))
        if (name.isNotBlank()) runCatching { accounts("update", mapOf("idToken" to j.str("idToken"), "displayName" to name, "returnSecureToken" to false)) }
        return sessionFrom(j, name)
    }

    fun sendPasswordReset(email: String) { accounts("sendOobCode", mapOf("requestType" to "PASSWORD_RESET", "email" to email)) }

    fun deleteAccount(idToken: String) { accounts("delete", mapOf("idToken" to idToken)) }

    /** Renueva el token. Lanza AuthException("AUTH") si la sesión ya no es válida. */
    fun refresh(s: Session): Session {
        val r = Http.call("POST", "https://securetoken.googleapis.com/v1/token?key=${FB.API_KEY}",
            "grant_type=refresh_token&refresh_token=" + Http.enc(s.refreshToken), "application/x-www-form-urlencoded")
        if (r.code !in 200..299) throw AuthException("AUTH", "Tu sesión ha caducado. Vuelve a iniciar sesión.")
        val j = Json.obj(r.body)
        return s.copy(idToken = j.str("id_token"), refreshToken = j.str("refresh_token").ifEmpty { s.refreshToken },
            exp = System.currentTimeMillis() + j.long("expires_in", 3600) * 1000 - 60_000)
    }
}

/** Documento de Firestore con un único campo "json" (cadena), como lo escribe la web. */
data class RemoteDoc(val value: JObj?, val updateTime: String?)

/** Operaciones remotas que necesita la sincronización (interfaz para poder probarla sin red). */
interface AcademicRemote {
    fun get(doc: String): RemoteDoc?
    fun getMany(docs: List<String>): Map<String, RemoteDoc?>
    /** Escribe si la versión remota sigue siendo [expectedUpdateTime] (null = que no exista). false = conflicto. */
    fun put(doc: String, value: JObj, expectedUpdateTime: String?): Boolean
    /** Escritura sin condición (preferencias). */
    fun putUnconditional(doc: String, value: JObj)
    fun delete(doc: String)
}

class FirestoreRest(private val uid: String, private val token: () -> String) : AcademicRemote {
    private fun path(doc: String) = "users/$uid/data/$doc"

    private fun parseDoc(j: JObj): RemoteDoc {
        val s = j.objOrNull("fields")?.objOrNull("json")?.str("stringValue")
        val v = s?.let { runCatching { Json.obj(it) }.getOrNull() }
        return RemoteDoc(v, j.strOrNull("updateTime"))
    }

    private fun check(r: Http.Resp) {
        if (r.code in 200..299) return
        val msg = runCatching { Json.obj(r.body).objOrNull("error")?.str("message") }.getOrNull().orEmpty()
        throw RemoteException(r.code, if (r.code == 401 || r.code == 403) "Sin permiso para tu cuenta. Vuelve a iniciar sesión." else msg.ifEmpty { "Error del servidor (${r.code})." })
    }

    override fun get(doc: String): RemoteDoc? {
        val r = Http.call("GET", "${FB.FS}/${path(doc)}", token = token())
        if (r.code == 404) return null
        check(r)
        return parseDoc(Json.obj(r.body))
    }

    override fun getMany(docs: List<String>): Map<String, RemoteDoc?> {
        val names = docs.map { "${FB.DOCS}/${path(it)}" }
        val r = Http.call("POST", "https://firestore.googleapis.com/v1/${FB.DOCS}:batchGet", Json.write(mapOf("documents" to names)), token = token())
        check(r)
        val out = HashMap<String, RemoteDoc?>()
        (Json.parse(r.body) as? List<*>).orEmpty().forEach { e ->
            val o = e as? JObj ?: return@forEach
            o.objOrNull("found")?.let { f -> out[f.str("name").substringAfterLast('/')] = parseDoc(f) }
            o.strOrNull("missing")?.let { m -> out[m.substringAfterLast('/')] = null }
        }
        return out
    }

    private fun body(value: JObj) = Json.write(mapOf("fields" to mapOf("json" to mapOf("stringValue" to Json.write(value)))))

    override fun put(doc: String, value: JObj, expectedUpdateTime: String?): Boolean {
        val pre = if (expectedUpdateTime == null) "currentDocument.exists=false" else "currentDocument.updateTime=" + Http.enc(expectedUpdateTime)
        val r = Http.call("PATCH", "${FB.FS}/${path(doc)}?$pre", body(value), token = token())
        // Condición incumplida: otro dispositivo escribió entre la lectura y la escritura.
        if (r.code == 400 && r.body.contains("FAILED_PRECONDITION") || r.code == 409 || r.code == 412) return false
        if (r.code == 404 && expectedUpdateTime != null) return false
        check(r)
        return true
    }

    override fun putUnconditional(doc: String, value: JObj) {
        check(Http.call("PATCH", "${FB.FS}/${path(doc)}", body(value), token = token()))
    }

    override fun delete(doc: String) {
        val r = Http.call("DELETE", "${FB.FS}/${path(doc)}", token = token())
        if (r.code != 404) check(r)
    }
}
