package app.minibunker.academic

import app.minibunker.json.*

/** Apariencia (se sincroniza con la cuenta en el documento prefs, como la web). */
data class UiPrefs(
    val accent: String = "azul", val mode: String = "oscuro", val updated: Long = 0,
    /** Intensidad del vidrio: 0 = más transparente, 1 = más tintado. Valor inicial intermedio. */
    val glass: Float = GLASS_DEFAULT,
) {
    fun toJson(): JObj = linkedMapOf("accent" to accent, "mode" to mode, "updated" to updated, "glass" to glass.toDouble())
    companion object {
        val ACCENTS = listOf("azul" to "Azul", "lila" to "Lila", "rosa" to "Rosa", "verde" to "Verde", "turquesa" to "Turquesa",
            "melocoton" to "Melocotón", "coral" to "Coral", "dorado" to "Dorado")
        const val GLASS_DEFAULT = 0.5f
        /**
         * [glassFallback]: la web de MIBUNKER no conoce «glass» y, al guardar sus preferencias, lo omite;
         * en ese caso se conserva la intensidad que ya había en el móvil.
         */
        fun from(o: JObj?, glassFallback: Float = GLASS_DEFAULT): UiPrefs? = o?.let {
            UiPrefs(it.str("accent").takeIf { a -> ACCENTS.any { x -> x.first == a } } ?: "azul",
                it.str("mode").takeIf { m -> m in setOf("oscuro", "claro", "auto") } ?: "oscuro", it.long("updated"),
                (it.num("glass")?.toFloat() ?: glassFallback).coerceIn(0f, 1f))
        }
    }
}
