package app.minibunker.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.study.*
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.FrostSheet
import app.minibunker.ui.frost.MenuOption
import app.minibunker.ui.theme.*
import app.thinktwice.core.AppState
import java.time.LocalDate

@Composable
fun EstudioScreen(tt: AppState, ac: AcadState) {
    val nav = LocalNav.current
    val a = ac.academic
    var section by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(nav.studySection) { nav.studySection?.let { section = it; nav.studySection = null } }
    val run by StudyController.run.collectAsState()
    val prefs by StudyController.prefs.collectAsState()
    val today = LocalDate.now(); val ts = Cal.iso(today)
    var manual by remember { mutableStateOf(false) }
    var durations by remember { mutableStateOf(false) }
    var planFor by remember { mutableStateOf<Grade?>(null) }
    var confirmDelPlan by remember { mutableStateOf<String?>(null) }
    var calcSubj by rememberSaveable { mutableStateOf("") }
    var calcTarget by rememberSaveable { mutableStateOf("5") }

    TabScaffold(
        "Estudio",
        actions = { Avatar(ac.account?.name ?: tt.settings.name) { nav.profileOpen = true } },
        below = { Segmented(listOf("Estudiar", "Planes", "Exámenes"), section, { section = it }, Modifier.fillMaxWidth()) },
    ) {
        when (section) {
            0 -> {
                item {
                    val r = run
                    if (r != null) TimerPanel(r, compact = true) { nav.push(Dest.StudySession) }
                    else TTCard {
                        Text("Temporizador", style = Type.label)
                        Text("${prefs.focus}:00", style = Type.timer)
                        Text("${prefs.focus} min de concentración · ${prefs.short} de descanso · ${prefs.long} de descanso largo tras cuatro bloques", style = Type.secondary)
                        Spacer(Modifier.height(14.dp))
                        PillButton("Empezar a estudiar", { nav.startStudy(StudyRequest(prefs.subject)) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow)
                        Spacer(Modifier.height(8.dp))
                        PillButton("Duraciones", { durations = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary, icon = Icons.Rounded.Timer)
                    }
                }
                // Resumen semanal y desglose diario.
                val ws = Cal.weekStart(today)
                val wk = a.sessions.filter { it.date >= Cal.iso(ws) && it.date <= ts }
                val tot = wk.sumOf { it.mins }
                val by = wk.groupBy { it.subject }.mapValues { e -> e.value.sumOf { it.mins } }.entries.sortedByDescending { it.value }
                item {
                    SectionHeader("Esta semana", "Añadir tiempo") { manual = true }
                    TTCard {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(Cal.fmtDur(tot), style = Type.cardFigure, modifier = Modifier.weight(1f))
                            Text("${Cal.fmtDur(Cal.minutesOn(a, ts))} hoy", style = Type.secondary)
                        }
                        Spacer(Modifier.height(14.dp))
                        var selDay by remember { mutableStateOf<Int?>(null) }
                        val days = (6 downTo 0).map { Cal.addD(ts, -it.toLong()) }
                        val mins = days.map { Cal.minutesOn(a, it) }
                        Text(selDay?.let { "${Cal.shortDay(days[it])} · ${Cal.fmtDur(mins[it])}" } ?: "Últimos 7 días · toca una barra", style = Type.bodyMedium, modifier = Modifier.padding(bottom = 8.dp))
                        BarChart(mins.map { it * 60_000L }, days.map { d -> Cal.DIAS[Cal.jsDay(Cal.parse(d)!!)].take(1).uppercase() }, selDay, { selDay = if (selDay == it) null else it }, height = 110.dp)
                    }
                }
                item {
                    SectionHeader("Por asignatura")
                    if (by.isEmpty()) Text("Usa el temporizador y aquí verás cuánto estudias de cada asignatura.", style = Type.secondary)
                    else ListGroup {
                        val mx = by.first().value.coerceAtLeast(1)
                        by.forEachIndexed { i, (s, m) ->
                            if (i > 0) RowDivider()
                            Column(Modifier.fillMaxWidth().pressable(scaleDown = false) { nav.push(Dest.SubjectHistory(s)) }.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ColorDot(hexColor(Cal.subjColor(a, s))); Spacer(Modifier.width(10.dp))
                                    Text(s, style = Type.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(Cal.fmtDur(m), style = Type.tabular.copy(color = TT.TextSecondary))
                                }
                                Spacer(Modifier.height(8.dp))
                                Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(TT.Control)) {
                                    Box(Modifier.fillMaxWidth(m.toFloat() / mx).fillMaxHeight().clip(CircleShape).background(hexColor(Cal.subjColor(a, s))))
                                }
                            }
                        }
                    }
                    Text("Solo cuenta el tiempo del temporizador y el que añades a mano; las horas planificadas o bloqueadas no se suman solas.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
                }
                val allSubj = a.sessions.map { it.subject }.distinct().sorted()
                if (allSubj.isNotEmpty()) item {
                    SectionHeader("Historial")
                    ListGroup {
                        allSubj.forEachIndexed { i, s ->
                            if (i > 0) RowDivider()
                            ListRow(s, "${a.sessions.count { it.subject == s }} sesiones · ${Cal.fmtDur(a.sessions.filter { it.subject == s }.sumOf { it.mins })}",
                                leading = { Box(Modifier.size(Dim.rowIcon), contentAlignment = Alignment.Center) { ColorDot(hexColor(Cal.subjColor(a, s)), 14.dp) } },
                                chevron = true, onClick = { nav.push(Dest.SubjectHistory(s)) })
                        }
                    }
                }
            }
            1 -> {
                val exams = a.grades.filter { it.score == null && it.date.isNotEmpty() && it.date >= ts }.sortedBy { it.date }
                item { Text("Genera actividades concretas por día con reglas locales (sin IA), reserva el último día para repaso y empieza a estudiar cada una con un toque.", style = Type.secondary) }
                if (exams.isEmpty()) item {
                    Spacer(Modifier.height(12.dp))
                    EmptyState(Icons.Rounded.Checklist, "Sin exámenes próximos", "Cuando añadas un examen con fecha, aquí podrás crear su plan de estudio.", "Nuevo examen") { nav.add = AddKind.EXAM }
                } else exams.forEach { g ->
                    item(key = g.id) {
                        Spacer(Modifier.height(14.dp))
                        PlanCard(a, g, onMake = { planFor = g }, onDelete = { confirmDelPlan = g.id })
                    }
                }
            }
            else -> {
                val subs = Cal.subjects(a)
                val graded = a.grades.filter { it.score != null }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.related)) {
                        TTCard(Modifier.weight(1f)) { Text("Media general", style = Type.label); Text(Cal.fmtN(Cal.overall(a)), style = Type.cardFigure) }
                        TTCard(Modifier.weight(1f)) { Text("Aprobados", style = Type.label); Text("${graded.count { (it.g10 ?: 0.0) >= 5 }}/${graded.size}", style = Type.cardFigure) }
                    }
                    Spacer(Modifier.height(12.dp))
                    PillButton("Nuevo examen", { nav.addDate = null; nav.add = AddKind.EXAM }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Add)
                }
                if (subs.isNotEmpty()) item {
                    SectionHeader("Por asignatura")
                    ListGroup {
                        subs.forEachIndexed { i, s ->
                            if (i > 0) RowDivider()
                            ListRow(s.name, "${s.graded} con nota · ${s.list.size - s.graded} pendientes",
                                leading = { Box(Modifier.size(Dim.rowIcon), contentAlignment = Alignment.Center) { ColorDot(hexColor(Cal.subjColor(a, s.name)), 14.dp) } },
                                value = Cal.fmtN(s.avg), chevron = true, onClick = { nav.push(Dest.SubjectGrades(s.name)) })
                        }
                    }
                    Text("Medias ponderadas sobre 10 con el peso de cada examen; sin peso, todos cuentan igual.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
                }
                item {
                    SectionHeader("¿Qué nota necesito?")
                    // Cualquier asignatura guardada, también las que aún no tienen exámenes.
                    val opts = subjectOptions(a)
                    if (opts.isEmpty()) Text("Crea una asignatura o añade un examen para calcular qué nota necesitas.", style = Type.secondary)
                    else {
                        val subj = opts.firstOrNull { it.value == calcSubj }?.value
                            ?: subs.firstOrNull { s -> s.list.any { it.score == null } }?.name?.let { n -> opts.firstOrNull { Cal.subjKey(it.value) == Cal.subjKey(n) }?.value }
                            ?: opts.first().value
                        TTCard {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                MenuField("Asignatura", opts, subj, Modifier.weight(1.4f)) { calcSubj = it }
                                LabeledField("Quiero sacar", calcTarget, { calcTarget = it.take(5) }, Modifier.weight(1f), numeric = true)
                            }
                            Spacer(Modifier.height(14.dp))
                            val target = calcTarget.replace(',', '.').toDoubleOrNull()
                            when {
                                target == null || target < 0 || target > 10 -> Text("Escribe la nota que quieres sacar, de 0 a 10.", style = Type.secondary)
                                else -> when (val x = Cal.needed(a, subj, target)) {
                                    Cal.Needed.NoExams -> Banner(BannerKind.Info, "Aún no hay exámenes registrados de $subj",
                                        "Añade sus exámenes pendientes (sin nota) y los que ya tengan nota para calcularlo.", "Añadir examen") { nav.addDate = null; nav.add = AddKind.EXAM }
                                    is Cal.Needed.NoPending -> Banner(BannerKind.Info, "No hay exámenes pendientes de $subj",
                                        "Tu media actual es ${Cal.fmtN(x.current)}. Para calcular qué necesitas, añade un examen pendiente (sin nota): no se cuenta como un cero.")
                                    is Cal.Needed.Result -> when {
                                        x.need <= 0 -> Banner(BannerKind.Ok, "¡Ya lo tienes!", "Aunque sacaras un 0 llegarías a un ${Cal.fmtN(target)}.")
                                        x.need > 10 -> Banner(BannerKind.Error, "No es posible llegar a un ${Cal.fmtN(target)}", "Sacando un 10 en todo llegarías a un ${Cal.fmtN(x.max)}.")
                                        else -> {
                                            Text(Cal.fmtN(Cal.roundUp2(x.need)), style = Type.hero, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
                                            Text("Es la nota media que necesitas en lo que queda para terminar con un ${Cal.fmtN(target)} en $subj", style = Type.secondary)
                                            Spacer(Modifier.height(8.dp))
                                            x.pending.forEach { g -> Text("· ${g.title.ifEmpty { "Examen" }} (${Cal.fmtD(g.date)}) cuenta un ${Cal.fmtN(Cal.weight(g) / x.totalW * 100)} %", style = Type.label) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                val pend = a.grades.filter { it.score == null }.sortedBy { it.date.ifEmpty { "9999" } }
                if (pend.isNotEmpty()) item { SectionHeader("Pendientes"); ExamList(a, pend) }
                val done = a.grades.filter { it.score != null }.sortedByDescending { it.date }
                if (done.isNotEmpty()) item { SectionHeader("Calificados"); ExamList(a, done) }
                if (a.grades.isEmpty()) item { Spacer(Modifier.height(12.dp)); EmptyState(Icons.Rounded.School, "Sin exámenes", "Registra exámenes pendientes o con nota para ver tus medias.") }
            }
        }
    }

    if (manual) ManualTimeSheet(a) { manual = false }
    if (durations) DurationsSheet { durations = false }
    planFor?.let { g -> PlanSheet(a, g) { planFor = null } }
    confirmDelPlan?.let { gid ->
        ConfirmDialog("Borrar plan", "Se borrarán todas sus tareas de estudio.", "Borrar",
            onConfirm = { AcademicRepo.edit { Edits.replacePlan(it, gid, emptyList()) }; confirmDelPlan = null; nav.show("Plan borrado") },
            onDismiss = { confirmDelPlan = null })
    }
}

@Composable
private fun ExamList(a: Academic, list: List<Grade>) {
    val nav = LocalNav.current
    ListGroup {
        list.forEachIndexed { i, g ->
            if (i > 0) RowDivider()
            Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).pressable(scaleDown = false) { nav.openExam = g.id }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                ColorDot(hexColor(Cal.subjColor(a, g.subject))); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(g.subject + if (g.title.isNotEmpty()) " · ${g.title}" else "", style = Type.bodyMedium, maxLines = 2)
                    Text(Cal.fmtD(g.date) + (g.weight?.let { " · cuenta ${Cal.fmtN(it)} %" } ?: ""), style = Type.secondary)
                }
                GradeBadge(g)
            }
        }
    }
}

@Composable
fun GradeBadge(g: Grade) {
    val v = g.g10
    val (bg, fg, txt) = when {
        v == null -> Triple(TT.Control, TT.TextSecondary, "Pendiente")
        v >= 5 -> Triple(TT.Positive.copy(alpha = 0.18f), TT.Positive, Cal.fmtN(g.score) + if (g.max != 10.0) "/${Cal.fmtN(g.max)}" else "")
        else -> Triple(TT.Danger.copy(alpha = 0.18f), TT.Danger, Cal.fmtN(g.score) + if (g.max != 10.0) "/${Cal.fmtN(g.max)}" else "")
    }
    Box(Modifier.clip(CircleShape).background(bg).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(txt, style = Type.label.copy(color = fg, fontFeatureSettings = "tnum"))
    }
}

/** Plan de un examen: progreso, temas por día (cada uno se puede empezar a estudiar) y acciones. */
@Composable
private fun PlanCard(a: Academic, g: Grade, onMake: () -> Unit, onDelete: () -> Unit) {
    val items = Cal.planOf(a, g.id)
    val done = items.count { it.done }
    val dl = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), Cal.parse(g.date) ?: LocalDate.now())
    TTCard(padding = 0.dp) {
        Column(Modifier.padding(start = Dim.cardPad, end = Dim.cardPad, top = Dim.cardPad)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ColorDot(hexColor(Cal.subjColor(a, g.subject)), 12.dp); Spacer(Modifier.width(10.dp))
                Text(g.subject + if (g.title.isNotEmpty()) " · ${g.title}" else "", style = Type.cardTitle, modifier = Modifier.weight(1f), maxLines = 2)
            }
            Text("${Cal.fmtD(g.date)} · " + when (dl) { 0L -> "hoy"; 1L -> "mañana"; else -> "en $dl días" }, style = Type.secondary)
            if (items.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LinearProgressIndicator(progress = { done / items.size.toFloat() }, modifier = Modifier.weight(1f).height(6.dp), color = TT.Positive, trackColor = TT.Control, drawStopIndicator = {})
                    Spacer(Modifier.width(10.dp)); Text("$done/${items.size}", style = Type.label.copy(fontFeatureSettings = "tnum"))
                }
            }
        }
        if (items.isEmpty()) {
            Column(Modifier.padding(Dim.cardPad)) {
                Text("Aún no tiene plan.", style = Type.secondary)
                Spacer(Modifier.height(10.dp))
                SmallPill("Generar plan de estudio", onMake, Icons.Rounded.Checklist, tone = ButtonTone.Light)
            }
        } else {
            Spacer(Modifier.height(6.dp))
            items.forEachIndexed { i, p -> if (i > 0) RowDivider(); PlanRow(p, a, showSubject = false) }
            Row(Modifier.padding(Dim.cardPad), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallPill("Revisar plan", onMake, Icons.Rounded.Edit)
                SmallPill("Borrar plan", onDelete, Icons.Rounded.Delete, tone = ButtonTone.Danger)
            }
        }
    }
}

/**
 * «Generar plan de estudio» sin IA: asignatura, temas escritos y fecha del examen → actividades por día
 * con plantillas locales. Primero los datos (precargados), luego la propuesta editable; guardar dos veces
 * deja una sola copia y las actividades ya completadas se conservan.
 */
@Composable
private fun PlanSheet(a: Academic, g: Grade, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ts = Cal.iso(LocalDate.now())
    val existing = remember(g.id) { Cal.planOf(a, g.id) }
    var topics by remember { mutableStateOf(PlanGen.topicsOf(existing).ifEmpty { listOfNotNull(g.title.takeIf { it.isNotBlank() }) }.joinToString("\n")) }
    var start by remember { mutableStateOf(maxOf(ts, existing.filter { !it.done }.minOfOrNull { it.date } ?: ts)) }
    var review by remember { mutableStateOf(existing.isEmpty() || existing.any { it.review }) }
    var proposal by remember { mutableStateOf<List<PlanItem>?>(null) }
    var saved by remember { mutableStateOf(false) }
    val lines = topics.lines().map { it.trim() }.filter { it.isNotEmpty() }
    val p = proposal
    FrostSheet(
        onDismiss, if (p == null) "Plan para ${g.subject.ifEmpty { "el examen" }}" else "Propuesta",
        primary = if (p == null) "Generar propuesta" else "Guardar plan",
        primaryEnabled = if (p == null) lines.isNotEmpty() else p.isNotEmpty() && !saved,
        onPrimary = {
            if (p == null) proposal = PlanGen.generate(g, lines, start, ts, review, existing)
            else if (!saved) {
                saved = true
                val clean = p.filter { it.title.isNotBlank() }.map { it.copy(title = it.title.trim()) }
                AcademicRepo.edit { Edits.replacePlan(it, g.id, clean) }
                val days = clean.map { it.date }.distinct().size
                nav.show("Plan guardado: ${clean.size} actividades en $days ${if (days == 1) "día" else "días"}"); onDismiss()
            }
        },
    ) {
        if (p == null) {
            Text("${g.subject.ifEmpty { "Examen" }}${if (g.title.isNotBlank()) " · ${g.title}" else ""} · ${Cal.fmtD(g.date)}", style = Type.secondary)
            Spacer(Modifier.height(12.dp))
            LabeledField("Temas (uno por línea)", topics, { topics = it.take(2000) }, singleLine = false, placeholder = "Tema 5: El relieve\nLa casa de Bernarda Alba…")
            val bare = lines.filter { PlanGen.isBareLabel(it) }
            if (bare.isNotEmpty()) Text(
                "«${bare.first()}» no tiene nombre. Puedes añadirlo o escribir sus apartados (por ejemplo «${bare.first()}: …»), o continuar con esa etiqueta: no se inventará su contenido.",
                style = Type.label, modifier = Modifier.padding(top = 6.dp),
            )
            Spacer(Modifier.height(14.dp))
            DateField("Empezar el", start) { start = it }
            Spacer(Modifier.height(14.dp))
            ListGroup { ListRow("Reservar el último día para repaso", "Si queda un solo día, práctica y repaso se hacen juntos", trailingSwitch = review, onSwitch = { review = it }, switchLabel = "Reservar último día para repaso") }
            Text("Las actividades terminan la víspera del examen. ${if (existing.any { it.done }) "Las ya completadas se conservan." else ""}", style = Type.label, modifier = Modifier.padding(top = 8.dp))
        } else {
            Text("Revisa y edita las actividades antes de guardar. Desde cada una podrás empezar a estudiar y marcar tu avance.", style = Type.secondary)
            Spacer(Modifier.height(10.dp))
            SmallPill("Cambiar los datos", { proposal = null }, Icons.Rounded.ArrowBack)
            p.groupBy { it.date }.forEach { (d, list) ->
                Text("${Cal.cap(Cal.shortDay(d))} · ${Cal.fmtD(d)}", style = Type.label.copy(color = TT.Text), modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
                list.forEach { it0 ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                        if (it0.done) Icon(Icons.Rounded.CheckCircle, "Completada", tint = TT.Positive, modifier = Modifier.size(22.dp).padding(end = 2.dp))
                        LabeledField("", it0.title, { v -> proposal = p.map { x -> if (x.id == it0.id) x.copy(title = v.take(160)) else x } }, Modifier.weight(1f), singleLine = false)
                        if (!it0.done) CircleIconButton(Icons.Rounded.Close, "Quitar actividad", { proposal = p.filter { x -> x.id != it0.id } })
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualTimeSheet(a: Academic, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ts = Cal.iso(LocalDate.now())
    var subj by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf(30) }
    var date by remember { mutableStateOf(ts) }
    FrostSheet(onDismiss, "Añadir tiempo de estudio", primary = "Añadir", onPrimary = {
        AcademicRepo.edit { Edits.upsertSession(it, StudySession(newUid(), subj.ifEmpty { "General" }, date, System.currentTimeMillis(), mins)) }
        nav.show("Tiempo añadido"); onDismiss()
    }) {
        MenuField("Asignatura", listOf(MenuOption("", "General")) + Cal.allSubjects(a).map { MenuOption(it, it) }, subj) { subj = it }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stepper("Minutos", mins, 1, 600, Modifier.weight(1f), step = 5) { mins = it }
            DateField("Día", date, Modifier.weight(1f)) { date = it }
        }
    }
}

@Composable
fun DurationsSheet(onDismiss: () -> Unit) {
    val p by StudyController.prefs.collectAsState()
    var f by remember { mutableStateOf(p.focus) }; var s by remember { mutableStateOf(p.short) }; var l by remember { mutableStateOf(p.long) }
    FrostSheet(onDismiss, "Duraciones", primary = "Guardar", onPrimary = { StudyController.setPrefs(p.copy(focus = f, short = s, long = l)); onDismiss() }) {
        Stepper("Concentración (min)", f, 1, 180, step = 5) { f = it }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stepper("Descanso corto", s, 1, 60, Modifier.weight(1f)) { s = it }
            Stepper("Descanso largo", l, 1, 120, Modifier.weight(1f), step = 5) { l = it }
        }
        Text("El descanso largo llega tras cuatro bloques completos.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
        SmallPill("Restablecer 25 / 5 / 15", { f = 25; s = 5; l = 15 }, Icons.Rounded.Refresh)
    }
}

/* ═════════════════════════ Detalles ═════════════════════════ */

@Composable
fun SubjectHistoryScreen(ac: AcadState, subject: String) {
    val a = ac.academic
    val list = a.sessions.filter { it.subject == subject }.sortedByDescending { it.date + "%015d".format(it.start) }
    DetailScaffold(subject) {
        item {
            Text("${Cal.fmtDur(list.sumOf { it.mins })} en ${list.size} ${if (list.size == 1) "sesión" else "sesiones"}", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
        }
        val byDay = list.groupBy { it.date }.toSortedMap(compareByDescending { it })
        if (byDay.isEmpty()) item { EmptyState(Icons.Rounded.History, "Sin sesiones", "El tiempo que estudies de esta asignatura aparecerá aquí.") }
        byDay.forEach { (d, ss) ->
            item(key = d) {
                Text(Cal.cap(Cal.rel(d)) + " · " + Cal.fmtD(d), style = Type.label, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp, start = 4.dp))
                ListGroup {
                    ss.forEachIndexed { i, s ->
                        if (i > 0) RowDivider()
                        val hh = if (s.start > 0) java.time.Instant.ofEpochMilli(s.start).atZone(java.time.ZoneId.systemDefault()).toLocalTime().toString().take(5) else ""
                        ListRow(Cal.fmtDur(s.mins), hh.ifEmpty { null }?.let { "Empezó a las $it" }, leading = { RowIcon(Icons.Rounded.Timer) })
                    }
                }
            }
        }
    }
}

@Composable
fun SubjectGradesScreen(ac: AcadState, subject: String) {
    val nav = LocalNav.current
    val a = ac.academic
    val s = Cal.subjects(a).firstOrNull { it.name == subject }
    DetailScaffold(subject) {
        item {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(Cal.fmtN(s?.avg), style = Type.hero)
                Spacer(Modifier.width(10.dp)); Text("de media", style = Type.secondary, modifier = Modifier.padding(bottom = 10.dp))
            }
            SectionHeader("Evolución")
            TTCard { GradeChart(s?.list.orEmpty()) }
            SectionHeader("Exámenes", "Nuevo") { nav.add = AddKind.EXAM }
            if (s != null) ExamList(a, s.list.sortedByDescending { it.date })
        }
    }
}

/** Evolución de notas (sobre 10) en el tiempo, con la línea del aprobado. */
@Composable
private fun GradeChart(list: List<Grade>) {
    val pts = list.filter { it.score != null }.sortedBy { it.date }
    if (pts.isEmpty()) { Text("Cuando pongas notas verás aquí cómo evolucionan.", style = Type.secondary); return }
    val line = TT.Accent; val grid = TT.Divider; val pass = TT.TextSecondary; val ok = TT.Positive; val bad = TT.Danger
    Canvas(Modifier.fillMaxWidth().height(170.dp).semantics { contentDescription = "Evolución: " + pts.joinToString(", ") { "${Cal.fmtD(it.date)} ${Cal.fmtN(it.score)}" } }) {
        val l = 8.dp.toPx(); val r = size.width - 8.dp.toPx(); val t = 8.dp.toPx(); val b = size.height - 8.dp.toPx()
        fun x(i: Int) = if (pts.size == 1) (l + r) / 2 else l + i * (r - l) / (pts.size - 1)
        fun y(v: Double) = (b - (v / 10.0) * (b - t)).toFloat()
        listOf(0.0, 2.5, 7.5, 10.0).forEach { v -> drawLine(grid, Offset(l, y(v)), Offset(r, y(v)), 1.dp.toPx()) }
        drawLine(pass, Offset(l, y(5.0)), Offset(r, y(5.0)), 1.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
        if (pts.size > 1) {
            val p = Path(); pts.forEachIndexed { i, g -> if (i == 0) p.moveTo(x(i), y(g.g10!!)) else p.lineTo(x(i), y(g.g10!!)) }
            drawPath(p, line, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))
        }
        pts.forEachIndexed { i, g -> drawCircle(if (g.g10!! >= 5) ok else bad, 5.dp.toPx(), Offset(x(i), y(g.g10!!))) }
    }
}
