package app.minibunker.ui.components

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.minibunker.R
import app.thinktwice.core.Fmt
import app.thinktwice.data.Store
import app.thinktwice.system.Apps
import app.minibunker.ui.theme.*
import app.minibunker.ui.frost.FrostSheet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ───────────────────────── Interacción ─────────────────────────

/** Pulsación con cambio inmediato y leve reducción de escala (0.98, ~120 ms). */
@Composable
fun Modifier.pressable(enabled: Boolean = true, role: Role = Role.Button, scaleDown: Boolean = true, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduce = LocalReduceMotion.current
    val s by animateFloatAsState(if (pressed && scaleDown && !reduce) Motion.pressScale else 1f, ttTween(Motion.press), label = "press")
    return this.scale(s).clickable(src, ttRipple(), enabled = enabled, role = role, onClick = onClick)
}

@Composable
private fun ttRipple() = ripple(color = TT.Text)

@Composable
fun rememberHaptic(): () -> Unit {
    val view = LocalView.current
    val enabled = Store.state.collectAsState().value.settings.haptics
    return remember(enabled) {
        {
            if (enabled) view.performHapticFeedback(
                if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.VIRTUAL_KEY
            )
        }
    }
}

// ───────────────────────── Botones ─────────────────────────

enum class ButtonTone { Light, Accent, Secondary, Danger }

@Composable
fun PillButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    tone: ButtonTone = ButtonTone.Light, enabled: Boolean = true, icon: ImageVector? = null,
) {
    val (bg, fg) = when (tone) {
        ButtonTone.Light -> TT.Text to TT.Bg
        ButtonTone.Accent -> TT.Accent to TT.OnAccent
        ButtonTone.Secondary -> TT.Control to TT.Text
        ButtonTone.Danger -> TT.Control to TT.Danger
    }
    Row(
        modifier
            .heightIn(min = Dim.buttonH)
            .clip(CircleShape)
            .background(if (enabled) bg else TT.Control)
            .pressable(enabled) { onClick() }
            .padding(horizontal = 24.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
    ) {
        val c = if (enabled) fg else TT.TextSecondary.copy(alpha = 0.6f)
        if (icon != null) { Icon(icon, null, tint = c, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = Type.button, color = c, textAlign = TextAlign.Center)
    }
}

@Composable
fun SmallPill(text: String, onClick: () -> Unit, icon: ImageVector? = null, tone: ButtonTone = ButtonTone.Secondary, modifier: Modifier = Modifier) {
    val (bg, fg) = when (tone) { ButtonTone.Accent -> TT.Accent to TT.OnAccent; ButtonTone.Light -> TT.Text to TT.Bg; ButtonTone.Danger -> TT.Control to TT.Danger; else -> TT.Control to TT.Text }
    Row(
        modifier.heightIn(min = Dim.touch).clip(CircleShape).background(bg).pressable { onClick() }.padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, style = Type.button.copy(fontSize = Type.secondary.fontSize), color = fg)
    }
}

@Composable
fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.width(80.dp).pressable(role = Role.Button) { onClick() }.semantics(mergeDescendants = true) {}.padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(Dim.quickAction).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = TT.Text, modifier = Modifier.size(Dim.icon))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, style = Type.label.copy(color = TT.Text), maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun CircleIconButton(icon: ImageVector, description: String, onClick: () -> Unit, bg: Color = TT.Control, size: Dp = 40.dp) {
    Box(
        Modifier.size(Dim.touch).pressable { onClick() }.semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = TT.Text, modifier = Modifier.size(20.dp))
        }
    }
}

// ───────────────────────── Superficies ─────────────────────────

@Composable
fun TTCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, padding: Dp = Dim.cardPad, content: @Composable ColumnScope.() -> Unit) {
    val depth = LocalMaterialDepth.current
    Column(
        modifier.fillMaxWidth().cardMaterial(RoundedCornerShape(Dim.cardRadius), depth).clip(RoundedCornerShape(Dim.cardRadius))
            .then(if (onClick != null) Modifier.pressable { onClick() } else Modifier)
            .padding(padding),
    ) {
        val scope = this
        CompositionLocalProvider(LocalMaterialDepth provides depth + 1) { scope.content() }
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = Dim.section, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = Type.section, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) Text(action, style = Type.bodyMedium.copy(color = TT.Accent),
            modifier = Modifier.clip(CircleShape).pressable { onAction() }.padding(horizontal = 8.dp, vertical = 12.dp))
    }
}

@Composable
fun CardHeader(title: String, subtitle: String? = null, showChevron: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Type.cardTitle)
            if (subtitle != null) Text(subtitle, style = Type.secondary)
        }
        if (showChevron) Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = TT.TextSecondary)
    }
}

@Composable
fun ListGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val depth = LocalMaterialDepth.current
    // El material se aplica una vez al contenedor; las filas se dibujan encima, con separadores discretos.
    Column(modifier.fillMaxWidth().cardMaterial(RoundedCornerShape(Dim.cardRadius), depth).clip(RoundedCornerShape(Dim.cardRadius))) {
        val scope = this
        CompositionLocalProvider(LocalMaterialDepth provides depth + 1) { scope.content() }
    }
}

@Composable
fun RowIcon(icon: ImageVector, tint: Color = TT.Text, bg: Color = TT.Control) {
    Box(Modifier.size(Dim.rowIcon).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
    }
}

/**
 * Fila de lista agrupada: icono a la izquierda, título y descripción, y valor/interruptor/flecha.
 * Si hay [onClick] y [trailingSwitch], las áreas táctiles están separadas por una línea vertical.
 */
@Composable
fun ListRow(
    title: String,
    subtitle: String? = null,
    leading: (@Composable () -> Unit)? = null,
    value: String? = null,
    chevron: Boolean = false,
    titleColor: Color = TT.Text,
    trailingSwitch: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null,
    switchLabel: String? = null,
    onClick: (() -> Unit)? = null,
) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(
            Modifier.weight(1f).heightIn(min = 64.dp)
                .then(if (onClick != null) Modifier.pressable(scaleDown = false) { onClick() } else Modifier)
                .padding(start = 16.dp, end = if (trailingSwitch != null && onClick != null) 8.dp else 16.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (leading != null) { leading(); Spacer(Modifier.width(14.dp)) }
            Column(Modifier.weight(1f)) {
                Text(title, style = Type.bodyMedium, color = titleColor, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (subtitle != null) Text(subtitle, style = Type.secondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            if (value != null) { Spacer(Modifier.width(8.dp)); Text(value, style = Type.body.copy(color = TT.TextSecondary), maxLines = 1) }
            if (chevron) Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = TT.TextSecondary)
        }
        if (trailingSwitch != null) {
            if (onClick != null) Box(Modifier.width(1.dp).height(28.dp).background(TT.Divider))
            Box(Modifier.padding(horizontal = 12.dp).semantics { if (switchLabel != null) contentDescription = switchLabel }) {
                TTSwitch(trailingSwitch, { onSwitch?.invoke(it) })
            }
        }
    }
}

@Composable
fun RowDivider() = Box(Modifier.padding(start = 70.dp).fillMaxWidth().height(1.dp).background(TT.Divider))

@Composable
fun TTSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked, onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = TT.Text, checkedTrackColor = TT.Accent, checkedBorderColor = TT.Accent,
            uncheckedThumbColor = TT.TextSecondary, uncheckedTrackColor = TT.Control, uncheckedBorderColor = TT.Control,
        ),
        thumbContent = { if (checked) Icon(Icons.Rounded.Check, null, tint = TT.Accent, modifier = Modifier.size(14.dp)) },
    )
}

// ───────────────────────── Selectores ─────────────────────────

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.clip(CircleShape).background(TT.Surface).padding(4.dp)) {
        options.forEachIndexed { i, o ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(CircleShape)
                    .background(if (sel) TT.Control else Color.Transparent)
                    .pressable(role = Role.Tab, scaleDown = false) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) { Text(o, style = Type.button.copy(fontSize = Type.secondary.fontSize), color = if (sel) TT.Text else TT.TextSecondary) }
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.heightIn(min = Dim.touch).clip(CircleShape)
            .background(if (selected) TT.Text else TT.Control)
            .pressable(role = Role.Checkbox) { onClick() }
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = Type.button.copy(fontSize = Type.secondary.fontSize), color = if (selected) TT.Bg else TT.Text) }
}

@Composable
fun DayChips(days: Set<Int>, onToggle: (Int) -> Unit) {
    val names = listOf("lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        (1..7).forEach { d ->
            val sel = d in days
            Box(
                Modifier.size(Dim.touch).clip(CircleShape).background(if (sel) TT.Text else TT.Control)
                    .pressable(role = Role.Checkbox) { onToggle(d) }
                    .semantics { contentDescription = names[d - 1] + if (sel) ", seleccionado" else ", no seleccionado" },
                contentAlignment = Alignment.Center,
            ) { Text(Fmt.dayLetter(d), style = Type.button, color = if (sel) TT.Bg else TT.Text) }
        }
    }
}

// ───────────────────────── Datos ─────────────────────────

/** Cifra protagonista: números grandes y unidades más pequeñas y ligeras. */
@Composable
fun HeroDuration(ms: Long?, modifier: Modifier = Modifier, style: androidx.compose.ui.text.TextStyle = Type.hero) {
    val unitSize = style.fontSize * 0.5f
    val text = if (ms == null) buildAnnotatedString { append("—") } else buildAnnotatedString {
        Fmt.durationParts(ms).forEachIndexed { i, (n, u) ->
            if (i > 0) append(" ")
            append(n)
            withStyle(SpanStyle(fontSize = unitSize, fontWeight = FontWeight.SemiBold, color = TT.TextSecondary, letterSpacing = Type.heroUnit.letterSpacing)) { append(" $u") }
        }
    }
    Text(text, style = style, modifier = modifier.semantics { contentDescription = ms?.let { Fmt.duration(it) } ?: "Sin datos" })
}

/** Indicador circular de productividad (uso clasificado). */
@Composable
fun Ring(percent: Int?, size: Dp = 112.dp, stroke: Dp = 10.dp, color: Color = TT.Accent) {
    val target = (percent ?: 0) / 100f
    val p by animateFloatAsState(target, ttTween(Motion.value), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val inset = sw / 2
            val arcSize = androidx.compose.ui.geometry.Size(this.size.width - sw, this.size.height - sw)
            val tl = androidx.compose.ui.geometry.Offset(inset, inset)
            drawArc(TT.Control, 0f, 360f, false, tl, arcSize, style = Stroke(sw))
            if (percent != null && p > 0f) drawArc(color, -90f, 360f * p, false, tl, arcSize, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(percent?.let { "$it%" } ?: "—", style = Type.cardFigure)
            if (percent == null) Text("Sin datos", style = Type.label)
        }
    }
}

/**
 * Gráfico de barras limpio. Al tocar una barra se muestra su dato encima del gráfico
 * (en una línea propia, sin tapar las barras). null = día sin datos (barra punteada baja).
 */
@Composable
fun BarChart(values: List<Long?>, labels: List<String>, selected: Int?, onSelect: (Int) -> Unit, modifier: Modifier = Modifier, height: Dp = 140.dp) {
    val max = (values.filterNotNull().maxOrNull() ?: 0L).coerceAtLeast(1L)
    val showEvery = if (values.size > 10) 5 else 1
    Column(modifier) {
        Row(Modifier.fillMaxWidth().height(height), horizontalArrangement = Arrangement.spacedBy(if (values.size > 10) 3.dp else 10.dp), verticalAlignment = Alignment.Bottom) {
            values.forEachIndexed { i, v ->
                val frac by animateFloatAsState(((v ?: 0L).toFloat() / max).coerceIn(0f, 1f), ttTween(Motion.value), label = "bar")
                val isSel = selected == i
                Box(
                    Modifier.weight(1f).fillMaxHeight().pressable(role = Role.Button, scaleDown = false) { onSelect(i) }
                        .semantics { contentDescription = "${labels[i]}: ${v?.let { Fmt.duration(it) } ?: "sin datos"}" },
                    contentAlignment = Alignment.BottomCenter,
                ) {
                    if (v == null) Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(TT.Control))
                    else Box(
                        Modifier.fillMaxWidth().fillMaxHeight(frac.coerceAtLeast(0.02f)).clip(RoundedCornerShape(6.dp))
                            .background(if (isSel || selected == null) TT.Accent else TT.Accent.copy(alpha = 0.35f))
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(if (values.size > 10) 3.dp else 10.dp)) {
            labels.forEachIndexed { i, l ->
                Text(if (i % showEvery == 0 || i == labels.lastIndex) l else "", style = Type.label, textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f), maxLines = 1, color = if (selected == i) TT.Text else TT.TextSecondary)
            }
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = Dim.rowIcon) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bmp by produceState<android.graphics.Bitmap?>(null, pkg, px) { value = withContext(Dispatchers.IO) { Apps.icon(ctx, pkg, px) } }
    Box(Modifier.size(size).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize()) }
            ?: Icon(Icons.Rounded.Apps, null, tint = TT.TextSecondary, modifier = Modifier.size(size / 2))
    }
}

@Composable
fun AppStack(pkgs: Collection<String>, max: Int = 4) {
    Row(horizontalArrangement = Arrangement.spacedBy((-8).dp), verticalAlignment = Alignment.CenterVertically) {
        pkgs.take(max).forEach { Box(Modifier.clip(CircleShape).background(TT.Card).padding(2.dp)) { AppIcon(it, 26.dp) } }
        if (pkgs.size > max) Box(Modifier.size(30.dp).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
            Text("+${pkgs.size - max}", style = Type.label.copy(color = TT.Text))
        }
    }
}

@Composable
fun appLabel(pkg: String): String {
    val ctx = LocalContext.current
    return remember(pkg) { Apps.label(ctx, pkg) }
}

@Composable
fun Logo(height: Dp, modifier: Modifier = Modifier) {
    // Logotipo original de thinktwice (blanco monocromo); en modo claro se tiñe del color del texto.
    Image(painterResource(R.drawable.logo_wordmark), "thinktwice", modifier.height(height),
        colorFilter = if (TT.isDark) null else androidx.compose.ui.graphics.ColorFilter.tint(TT.Text))
}

// ───────────────────────── Estados ─────────────────────────

enum class BannerKind { Error, Info, Ok }

@Composable
fun Banner(kind: BannerKind, title: String, text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    val (icon, tint) = when (kind) {
        BannerKind.Error -> Icons.Rounded.ErrorOutline to TT.Danger
        BannerKind.Info -> Icons.Rounded.Info to TT.Accent
        BannerKind.Ok -> Icons.Rounded.CheckCircle to TT.Positive
    }
    TTCard(onClick = onAction) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = Type.bodyMedium)
                Text(text, style = Type.secondary)
                if (action != null) { Spacer(Modifier.height(8.dp)); Text(action, style = Type.bodyMedium.copy(color = TT.Accent)) }
            }
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    TTCard {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            RowIcon(icon, TT.TextSecondary)
            Spacer(Modifier.height(12.dp))
            Text(title, style = Type.cardTitle, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(text, style = Type.secondary, textAlign = TextAlign.Center)
            if (action != null && onAction != null) { Spacer(Modifier.height(16.dp)); SmallPill(action, onAction, Icons.Rounded.Add) }
        }
    }
}

@Composable
fun StatusDot(ok: Boolean?, text: String) {
    val (c, i) = when (ok) { true -> TT.Positive to Icons.Rounded.CheckCircle; false -> TT.Danger to Icons.Rounded.Cancel; null -> TT.TextSecondary to Icons.Rounded.RemoveCircleOutline }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(i, null, tint = c, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
        Text(text, style = Type.label.copy(color = c))
    }
}

// ───────────────────────── Formularios ─────────────────────────

/** Campo con etiqueta persistente (no solo placeholder), ayuda breve y error junto al campo. */
@Composable
fun LabeledField(
    label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier,
    help: String? = null, error: String? = null, numeric: Boolean = false, singleLine: Boolean = true, placeholder: String? = null,
) {
    Column(modifier.fillMaxWidth()) {
        Text(label, style = Type.label.copy(color = TT.Text))
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = singleLine,
            placeholder = placeholder?.let { { Text(it, style = Type.body.copy(color = TT.TextSecondary)) } },
            isError = error != null, textStyle = Type.body,
            keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TT.Control, unfocusedContainerColor = TT.Control, errorContainerColor = TT.Control,
                focusedBorderColor = TT.Accent, unfocusedBorderColor = Color.Transparent, errorBorderColor = TT.Danger,
                cursorColor = TT.Accent, focusedTextColor = TT.Text, unfocusedTextColor = TT.Text,
            ),
        )
        when {
            error != null -> Text(error, style = Type.label.copy(color = TT.Danger), modifier = Modifier.padding(top = 6.dp))
            help != null -> Text(help, style = Type.label, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/**
 * Confirmación sobre la superficie translúcida compartida (en lugar de un diálogo del sistema).
 * Se muestra mientras se declare.
 */
@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, danger: Boolean = true, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    FrostSheet(onDismiss, title, scrollable = false, footer = {
        Spacer(Modifier.height(18.dp))
        PillButton(confirm, onConfirm, Modifier.fillMaxWidth(), tone = if (danger) ButtonTone.Danger else ButtonTone.Light)
        Spacer(Modifier.height(Dim.related))
        PillButton("Cancelar", onDismiss, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary)
    }) {
        Text(text, style = Type.body.copy(color = TT.TextSecondary))
    }
}

/**
 * Logotipo principal de fuckstudy: las imágenes originales (fondo transparente), sin texto reconstruido,
 * sin invertir colores, sin acento y sin placa. Letras blancas en tema oscuro y negras en tema claro;
 * en modo automático sigue el tema efectivo y cambia en el momento si el tema cambia con la vista abierta.
 */
@Composable
fun MbWordmark(modifier: Modifier = Modifier, height: Dp = 30.dp) {
    val res = if (TT.isDark) R.drawable.fs_logo_dark else R.drawable.fs_logo_light
    Image(painterResource(res), "fuckstudy", modifier.height(height).aspectRatio(969f / 250f), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
}

/** Avatar del perfil (abre la hoja de perfil). */
@Composable
fun Avatar(name: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val nav = app.minibunker.ui.LocalNav.current
    val fr = remember { androidx.compose.ui.focus.FocusRequester() }
    Box(
        modifier.size(Dim.touch).focusRequester(fr).pressable { nav.lastOpener = fr; onClick() }.semantics { contentDescription = "Perfil" },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
            val initial = name.trim().firstOrNull()?.uppercase()
            if (initial != null) Text(initial, style = Type.cardTitle)
            else Icon(Icons.Rounded.Person, null, tint = TT.Text, modifier = Modifier.size(20.dp))
        }
    }
}

/** Punto de color (asignaturas, eventos). */
@Composable
fun ColorDot(color: Color, size: Dp = 10.dp) = Box(Modifier.size(size).clip(CircleShape).background(color))

fun hexColor(hex: String, fallback: Color = Color(0xFF6F9DE0)): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(fallback)
