package app.minibunker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.minibunker.academic.*
import app.minibunker.link.Links
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.FrostSheet
import app.minibunker.ui.theme.*
import app.thinktwice.core.AppState
import app.thinktwice.data.Store
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun AgendaScreen(tt: AppState, ac: AcadState) {
    val nav = LocalNav.current
    val a = ac.academic
    var section by rememberSaveable { mutableIntStateOf(0) }
    val today = LocalDate.now()
    var sel by rememberSaveable { mutableStateOf(Cal.iso(today)) }
    var ym by rememberSaveable { mutableStateOf(YearMonth.from(today).toString()) }
    LaunchedEffect(nav.agendaSection, nav.agendaDay) {
        nav.agendaSection?.let { section = it; nav.agendaSection = null }
        nav.agendaDay?.let { d -> sel = d; Cal.parse(d)?.let { ym = YearMonth.from(it).toString() }; nav.agendaDay = null }
    }
    val month = YearMonth.parse(ym)
    var classSheet by remember { mutableStateOf<Pair<Int, JornadaItem.Slot>?>(null) }
    var jornadaOpen by remember { mutableStateOf(false) }
    var subjectSheet by remember { mutableStateOf<String?>(null) } // "" = nueva
    var slotSheet by remember { mutableStateOf<JornadaItem.Slot?>(null) }
    var addSlot by remember { mutableStateOf(false) }
    var dayList by remember { mutableStateOf<String?>(null) }

    TabScaffold(
        "Agenda",
        actions = { Avatar(ac.account?.name ?: tt.settings.name) { nav.profileOpen = true } },
        below = { Segmented(listOf("Mes", "Horario"), section, { section = it }, Modifier.fillMaxWidth()) },
    ) {
        if (section == 0) {
            item { MonthHeader(month, onPrev = { ym = month.minusMonths(1).toString() }, onNext = { ym = month.plusMonths(1).toString() },
                onToday = { ym = YearMonth.from(today).toString(); sel = Cal.iso(today) }) }
            item { MonthGrid(a, month, sel) { sel = it; if (Cal.dayItems(a, it).isNotEmpty()) dayList = it } }
            item {
                val d = Cal.parse(sel) ?: today
                Spacer(Modifier.height(20.dp))
                Text(Cal.longDate(d), style = Type.section, modifier = Modifier.semantics { heading() })
                Text(Cal.rel(sel), style = Type.secondary)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallPill("Evento", { nav.addDate = sel; nav.add = AddKind.EVENT }, Icons.Rounded.Add, tone = ButtonTone.Light)
                    SmallPill("Examen", { nav.addDate = sel; nav.add = AddKind.EXAM }, Icons.Rounded.Add)
                }
                Spacer(Modifier.height(12.dp))
                DayDetail(a, d) { day, sl -> classSheet = day to sl }
            }
        } else {
            val slots = Cal.slots(a)
            if (slots.isEmpty()) item {
                EmptyState(Icons.Rounded.Schedule, "Crea tu horario", "Configura tus días lectivos, la hora de inicio, la duración de las clases y los recreos. Luego toca cada hueco para poner la asignatura.",
                    "Configurar jornada") { jornadaOpen = true }
            } else {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallPill("Jornada", { jornadaOpen = true }, Icons.Rounded.Tune)
                        SmallPill("Hueco", { addSlot = true }, Icons.Rounded.Add)
                        SmallPill("Asignatura", { subjectSheet = "" }, Icons.Rounded.Add)
                    }
                    Spacer(Modifier.height(14.dp))
                    WeekGrid(tt, a, slots, onCell = { day, sl -> classSheet = day to sl }, onSlot = { slotSheet = it })
                    Text("Toca un hueco para asignar una clase y, si quieres, vincular su protección. Toca una hora para cambiarla.", style = Type.label, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item { SectionHeader("Asignaturas", "Nueva") { subjectSheet = "" } }
            item {
                val subs = Cal.subjList(a)
                if (subs.isEmpty()) EmptyState(Icons.Rounded.MenuBook, "Sin asignaturas", "Crea tus asignaturas con color, profesor y aula.", "Nueva asignatura") { subjectSheet = "" }
                else ListGroup {
                    subs.forEachIndexed { i, s ->
                        if (i > 0) RowDivider()
                        val mins = Cal.minutesOf(a, s.name)
                        ListRow(s.name, listOf(s.teacher, s.room).filter { it.isNotEmpty() }.joinToString(" · ").ifEmpty { "Sin profesor ni aula" } +
                                (if (mins > 0) " · ${Cal.fmtDur(mins)}/semana" else ""),
                            leading = { Box(Modifier.size(Dim.rowIcon), contentAlignment = Alignment.Center) { ColorDot(hexColor(s.color), 16.dp) } },
                            chevron = true, onClick = { subjectSheet = s.name })
                    }
                }
            }
        }
    }

    classSheet?.let { (day, sl) -> ClassSheet(tt, a, day, sl, onNewSubject = { subjectSheet = "" }) { classSheet = null } }
    if (jornadaOpen) JornadaSheet(a) { jornadaOpen = false }
    subjectSheet?.let { n -> SubjectSheet(a, n.ifEmpty { null }) { subjectSheet = null } }
    slotSheet?.let { SlotSheet(a, it) { slotSheet = null } }
    if (addSlot) AddSlotSheet(a) { addSlot = false }
    dayList?.let { DayListSheet(a, it) { dayList = null } }
}

@Composable
private fun MonthHeader(m: YearMonth, onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleIconButton(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, "Mes anterior", onPrev)
        Text(Cal.cap(Cal.MESES[m.monthValue - 1]) + " ${m.year}", style = Type.cardTitle, textAlign = TextAlign.Center, modifier = Modifier.weight(1f).semantics { liveRegion = LiveRegionMode.Polite })
        CircleIconButton(Icons.AutoMirrored.Rounded.KeyboardArrowRight, "Mes siguiente", onNext)
        Spacer(Modifier.width(4.dp))
        SmallPill("Hoy", onToday)
    }
}

@Composable
private fun MonthGrid(a: Academic, m: YearMonth, sel: String, onSelect: (String) -> Unit) {
    val first = m.atDay(1)
    val lead = first.dayOfWeek.value - 1 // lunes primero
    val days = m.lengthOfMonth()
    val today = Cal.iso(LocalDate.now())
    TTCard(padding = 10.dp) {
        Row(Modifier.fillMaxWidth()) {
            listOf("L", "M", "X", "J", "V", "S", "D").forEach { Text(it, style = Type.label, textAlign = TextAlign.Center, modifier = Modifier.weight(1f).padding(vertical = 6.dp)) }
        }
        val cells = lead + days
        val rows = (cells + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val idx = r * 7 + c - lead + 1
                    if (idx < 1 || idx > days) { Spacer(Modifier.weight(1f).height(52.dp)); continue }
                    val ds = Cal.iso(m.atDay(idx))
                    val its = Cal.dayItems(a, ds)
                    val (titles, more) = Cal.cellTitles(a, ds, 3)
                    val isSel = ds == sel; val isToday = ds == today
                    val fg = if (isSel) TT.OnAccent else TT.Text
                    Column(
                        Modifier.weight(1f).heightIn(min = 78.dp).padding(1.5.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) TT.Accent else Color.Transparent)
                            // Hoy: aro (también sobre la selección, con el color de contraste); seleccionado: relleno.
                            .then(if (isToday) Modifier.border(1.5.dp, if (isSel) TT.OnAccent else TT.Accent, RoundedCornerShape(12.dp)) else Modifier)
                            .pressable(scaleDown = false) { onSelect(ds) }
                            .semantics(mergeDescendants = true) {
                                contentDescription = "$idx de ${Cal.MESES[m.monthValue - 1]}" +
                                    if (its.isNotEmpty()) ": " + its.joinToString(", ") { (if (it.time.isNotEmpty()) it.time + " " else "") + it.title } else ""
                                selected = isSel
                                if (isToday) stateDescription = "Hoy"
                            }
                            .padding(horizontal = 2.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("$idx", style = Type.bodyMedium.copy(color = fg, fontFeatureSettings = "tnum",
                            fontWeight = if (isToday) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Medium))
                        Spacer(Modifier.height(2.dp))
                        // Títulos breves dentro del día (en lugar de puntos) y «+N más» si no caben.
                        titles.forEach { (t, exam) ->
                            val bg = when {
                                isSel -> TT.OnAccent.copy(alpha = 0.16f)
                                exam -> TT.Warm.copy(alpha = 0.22f)
                                else -> TT.Accent.copy(alpha = 0.18f)
                            }
                            Text(
                                t, maxLines = 1, overflow = TextOverflow.Clip, softWrap = false,
                                style = Type.label.copy(fontSize = 9.sp, lineHeight = 11.sp, color = fg),
                                modifier = Modifier.fillMaxWidth().padding(top = 1.dp).clip(RoundedCornerShape(4.dp)).background(bg).padding(horizontal = 2.dp, vertical = 1.dp),
                            )
                        }
                        if (more > 0) Text("+$more más", maxLines = 1, softWrap = false, style = Type.label.copy(fontSize = 9.sp, lineHeight = 11.sp, color = if (isSel) TT.OnAccent else TT.TextSecondary))
                    }
                }
            }
        }
    }
}

/** Lista completa de un día al tocarlo en la cuadrícula: nombres y horas; cada examen aparece una sola vez. */
@Composable
private fun DayListSheet(a: Academic, ds: String, onDismiss: () -> Unit) {
    val d = Cal.parse(ds) ?: LocalDate.now()
    val items = Cal.dayItems(a, ds)
    FrostSheet(onDismiss, Cal.longDate(d)) {
        Text(Cal.rel(ds), style = Type.secondary)
        Spacer(Modifier.height(12.dp))
        ListGroup { items.forEachIndexed { i, it -> if (i > 0) RowDivider(); DayItemRow(it, a) } }
        Spacer(Modifier.height(8.dp))
    }
}

/** Detalle del día: eventos, exámenes, clases, tareas de estudio y minutos estudiados. */
@Composable
private fun DayDetail(a: Academic, d: LocalDate, onClass: (Int, JornadaItem.Slot) -> Unit) {
    val ds = Cal.iso(d)
    val items = Cal.dayItems(a, ds)
    val cls = Cal.classesOn(a, d)
    val plans = a.plans.filter { it.date == ds }
    val mins = Cal.minutesOn(a, ds)
    if (items.isEmpty() && cls.isEmpty() && plans.isEmpty()) {
        Text("Nada apuntado este día.", style = Type.secondary, modifier = Modifier.padding(vertical = 8.dp))
    }
    if (items.isNotEmpty()) ListGroup { items.forEachIndexed { i, it -> if (i > 0) RowDivider(); DayItemRow(it, a) } }
    if (cls.isNotEmpty()) {
        Text("Clases", style = Type.label, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp, start = 4.dp))
        ListGroup {
            cls.forEachIndexed { i, c ->
                if (i > 0) RowDivider()
                val sl = Cal.slots(a).firstOrNull { if (c.slot.isNotEmpty()) it.id == c.slot else it.start == c.start && it.end == c.end }
                    ?: JornadaItem.Slot(c.slot, false, c.start, c.end)
                ClassRow(c) { onClass(c.day, sl) }
            }
        }
    }
    if (plans.isNotEmpty()) {
        Text("Estudio", style = Type.label, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp, start = 4.dp))
        ListGroup { plans.forEachIndexed { i, p -> if (i > 0) RowDivider(); PlanRow(p, a, showDate = false) } }
    }
    if (mins > 0) Text("Estudiaste ${Cal.fmtDur(mins)} este día.", style = Type.secondary, modifier = Modifier.padding(top = 14.dp, start = 4.dp))
}

@Composable
private fun ClassRow(c: ClassEntry, onClick: () -> Unit) {
    val linked = Store.state.collectAsState().value.routines.any { it.link == Links.classKey(c.id) }
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).pressable(scaleDown = false) { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.width(52.dp)) {
            Text(c.start, style = Type.label.copy(color = TT.Text, fontFeatureSettings = "tnum")); Text(c.end, style = Type.label.copy(fontFeatureSettings = "tnum"))
        }
        Box(Modifier.width(4.dp).height(34.dp).clip(CircleShape).background(hexColor(c.color)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.subject, style = Type.bodyMedium)
            Text(listOf(c.teacher, c.room).filter { it.isNotEmpty() }.joinToString(" · ").ifEmpty { "Clase" }, style = Type.secondary)
        }
        if (linked) Icon(Icons.Rounded.Shield, "Protección vinculada", tint = TT.AccentText, modifier = Modifier.size(18.dp))
    }
}

/** Horario semanal: filas = huecos (con recreos), columnas = días lectivos. */
@Composable
private fun WeekGrid(tt: AppState, a: Academic, slots: List<JornadaItem.Slot>, onCell: (Int, JornadaItem.Slot) -> Unit, onSlot: (JornadaItem.Slot) -> Unit) {
    val days = Cal.ttDays(a)
    val todayJs = Cal.jsDay(LocalDate.now())
    val linked = tt.routines.mapNotNull { it.link }.toSet()
    val short = listOf("D", "L", "M", "X", "J", "V", "S")
    TTCard(padding = 8.dp) {
        Row(Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(54.dp))
            days.forEach { d -> Text(short[d], style = Type.label.copy(color = if (d == todayJs) TT.AccentText else TT.TextSecondary), textAlign = TextAlign.Center, modifier = Modifier.weight(1f).padding(vertical = 6.dp)) }
        }
        slots.forEach { sl ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(
                    Modifier.width(54.dp).heightIn(min = if (sl.isBreak) 32.dp else 52.dp).clip(RoundedCornerShape(10.dp))
                        .pressable(scaleDown = false) { onSlot(sl) }
                        .semantics(mergeDescendants = true) { contentDescription = (if (sl.isBreak) "Recreo" else "Hueco") + " de ${sl.start} a ${sl.end}, cambiar horas" },
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(sl.start, style = Type.label.copy(color = TT.Text, fontFeatureSettings = "tnum", fontSize = 11.sp))
                    if (!sl.isBreak) Text(sl.end, style = Type.label.copy(fontFeatureSettings = "tnum", fontSize = 11.sp))
                }
                if (sl.isBreak) {
                    Box(Modifier.weight(1f).height(28.dp).clip(RoundedCornerShape(10.dp)).background(TT.Control.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
                        Text("Recreo · ${sl.start} – ${sl.end}", style = Type.label)
                    }
                } else days.forEach { d ->
                    val e = Cal.entryAt(a, d, sl)
                    val col = e?.let { hexColor(it.color) }
                    Box(
                        Modifier.weight(1f).height(52.dp).padding(2.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (e != null) TT.Accent.copy(alpha = if (TT.isDark) 0.34f else 0.22f) else TT.Control.copy(alpha = 0.45f))
                            .pressable(scaleDown = false) { onCell(d, sl) }
                            .semantics { contentDescription = "${Cal.DAYN[d]} ${sl.start}: " + (e?.subject ?: "libre, asignar clase") },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (e != null) {
                            val fg = TT.Text
                            // Color propio de la asignatura como pequeño detalle identificativo.
                            Box(Modifier.align(Alignment.CenterStart).padding(start = 3.dp).width(3.dp).fillMaxHeight(0.6f).clip(CircleShape).background(col!!))
                            Text(e.subject, style = Type.label.copy(color = fg, fontSize = 11.sp, lineHeight = 13.sp), maxLines = 2, overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 3.dp))
                            if (Links.classKey(e.id) in linked) Icon(Icons.Rounded.Shield, null, tint = fg, modifier = Modifier.size(11.dp).align(Alignment.TopEnd).padding(1.dp))
                        } else Icon(Icons.Rounded.Add, null, tint = TT.TextSecondary.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

/* ═════════════════════════ Hojas ═════════════════════════ */

/** Asignar (o vaciar) un hueco del horario, con «Vincular protección» opcional. */
@Composable
fun ClassSheet(tt: AppState, a: Academic, day: Int, slot: JornadaItem.Slot, onNewSubject: () -> Unit, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val e = Cal.entryAt(a, day, slot)
    val subs = Cal.subjList(a)
    var chosen by remember { mutableStateOf(e?.subject) }
    var also by remember { mutableStateOf(setOf<Int>()) }
    val existingLink = e?.let { ent -> tt.routines.firstOrNull { it.link == Links.classKey(ent.id) } }
    var protect by remember { mutableStateOf(existingLink != null && existingLink.enabled) }
    var apps by remember { mutableStateOf(existingLink?.packages ?: tt.templates.firstOrNull { it.id == "t_study" }?.packages ?: emptySet()) }

    fun save() {
        val name = chosen ?: return
        val days = listOf(day) + also.toList()
        AcademicRepo.edit { Edits.setCells(it, days, slot, name) }
        val now = AcademicRepo.state.value.academic
        val sl = Cal.slots(now).firstOrNull { it.start == slot.start && it.end == slot.end } ?: slot
        Store.update { s ->
            var rs = s.routines
            days.forEach { d ->
                val ent = Cal.entryAt(now, d, sl) ?: return@forEach
                rs = if (protect && apps.isNotEmpty()) Links.upsert(now, rs, Links.classKey(ent.id), apps) { Store.newId() } else Links.remove(rs, Links.classKey(ent.id))
            }
            s.copy(routines = rs)
        }
        nav.show(if (days.size > 1) "$name en ${days.size} días" else "$name · ${Cal.DAYN[day].lowercase()} ${slot.start}")
        onDismiss()
    }

    FrostSheet(onDismiss, "${Cal.DAYN[day]} · ${slot.start}–${slot.end}", primary = "Guardar", primaryEnabled = chosen != null && (!protect || apps.isNotEmpty()), onPrimary = ::save) {
        FieldLabel("Elige la asignatura")
        if (subs.isEmpty()) Text("Aún no tienes asignaturas.", style = Type.secondary)
        else ListGroup {
            subs.forEachIndexed { i, s ->
                if (i > 0) RowDivider()
                val on = chosen == s.name
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).pressable(scaleDown = false, role = Role.RadioButton) { chosen = s.name }
                    .semantics { selected = on }.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    ColorDot(hexColor(s.color), 14.dp); Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = Type.bodyMedium)
                        val det = listOf(s.teacher, s.room).filter { it.isNotEmpty() }.joinToString(" · ")
                        if (det.isNotEmpty()) Text(det, style = Type.secondary)
                    }
                    if (on) Icon(Icons.Rounded.Check, null, tint = TT.AccentText)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        SmallPill("Nueva asignatura", { onNewSubject() }, Icons.Rounded.Add)
        val others = Cal.ttDays(a).filter { it != day }
        if (others.isNotEmpty() && chosen != null) {
            Spacer(Modifier.height(18.dp))
            FieldLabel("Poner también los…")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                others.forEach { d -> Chip(Cal.DAYN[d].take(3), d in also, { also = if (d in also) also - d else also + d }) }
            }
        }
        if (chosen != null) {
            Spacer(Modifier.height(18.dp))
            ProtectionChooser(tt, "Vincular protección", "Pausa las apps que elijas durante esta clase, cada semana", protect, { protect = it }, apps, { apps = it })
        }
        if (e != null) {
            Spacer(Modifier.height(18.dp))
            PillButton("Dejar este hueco libre", {
                AcademicRepo.edit { Edits.setCells(it, listOf(day), slot, null) }
                Store.update { s -> s.copy(routines = Links.remove(s.routines, Links.classKey(e.id))) }
                nav.show("Hueco libre"); onDismiss()
            }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary)
        }
    }
}

/** Jornada: días lectivos, inicio, duración de clases y recreos, con vista previa antes de aplicar. */
@Composable
fun JornadaSheet(a: Academic, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val cfg = Cal.cfg(a)
    val existing = Cal.slots(a).filter { !it.isBreak }
    val init = cfg?.gen ?: JornadaGen(existing.firstOrNull()?.start ?: "08:00",
        existing.firstOrNull()?.let { Cal.toMin(it.end) - Cal.toMin(it.start) } ?: 60, existing.size.takeIf { it > 0 } ?: 6, 3, 30, 0, 0)
    var g by remember { mutableStateOf(init) }
    var days by remember { mutableStateOf(Cal.ttDays(a).toSet()) }
    var confirm by remember { mutableStateOf<Int?>(null) }
    val preview = Cal.genSlots(g)

    fun apply() {
        AcademicRepo.edit { Edits.applyJornada(it, g, days.sorted()) }
        nav.show(if (cfg != null) "Jornada guardada" else "¡Listo! Ahora pon tus asignaturas"); onDismiss()
    }

    FrostSheet(onDismiss, if (cfg != null) "Tu jornada" else "Crea tu horario", primary = if (cfg != null) "Guardar jornada" else "Crear mi horario",
        primaryEnabled = days.isNotEmpty(), onPrimary = {
            val lost = Edits.jornadaLosses(a, g, days.sorted()).size
            if (lost > 0) confirm = lost else apply()
        }) {
        FieldLabel("Días lectivos")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..6).forEach { d -> Chip(Cal.DAYN[d].take(3), d in days, { days = if (d in days) days - d else days + d }) }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TimeField("Primera clase", g.start, Modifier.weight(1f), allowEmpty = false) { g = g.copy(start = it) }
            Stepper("Clases", g.n, 1, 12, Modifier.weight(1f)) { g = g.copy(n = it) }
        }
        Spacer(Modifier.height(16.dp))
        FieldLabel("Duración de cada clase")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(45, 50, 55, 60).forEach { m -> Chip("$m min", g.dur == m, { g = g.copy(dur = m) }) }
        }
        Spacer(Modifier.height(8.dp))
        Stepper("Otra duración (min)", g.dur, 10, 180) { g = g.copy(dur = it) }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stepper("Recreo tras la clase", g.b1a, 0, 11, Modifier.weight(1f)) { g = g.copy(b1a = it) }
            Stepper("Dura (min)", g.b1, 0, 120, Modifier.weight(1f), step = 5) { g = g.copy(b1 = it) }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stepper("2.º recreo tras", g.b2a, 0, 11, Modifier.weight(1f)) { g = g.copy(b2a = it) }
            Stepper("Dura (min)", g.b2, 0, 120, Modifier.weight(1f), step = 5) { g = g.copy(b2 = it) }
        }
        Spacer(Modifier.height(18.dp))
        FieldLabel("Vista previa")
        ListGroup {
            preview.forEachIndexed { i, s ->
                if (i > 0) RowDivider()
                ListRow(if (s.isBreak) "Recreo" else "Clase ${preview.take(i + 1).count { !it.isBreak }}", null, value = "${s.start} – ${s.end}")
            }
        }
        Text("Termina a las ${preview.lastOrNull()?.end ?: g.start}.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
    }
    confirm?.let { n ->
        ConfirmDialog("Cambiar la jornada", "$n ${if (n == 1) "clase ya no encaja" else "clases ya no encajan"} en la nueva jornada y se quitarán del horario.", "Continuar",
            onConfirm = { confirm = null; apply() }, onDismiss = { confirm = null })
    }
}

/** Contador con − y + (objetivos táctiles de 48 dp). */
@Composable
fun Stepper(label: String, value: Int, min: Int, max: Int, modifier: Modifier = Modifier, step: Int = 1, onChange: (Int) -> Unit) {
    Column(modifier) {
        FieldLabel(label)
        Row(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp)).background(TT.Control), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(Dim.touch).pressable(enabled = value > min) { onChange((value - step).coerceAtLeast(min)) }.semantics { contentDescription = "Menos $label" }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Remove, null, tint = if (value > min) TT.Text else TT.TextSecondary)
            }
            Text("$value", style = Type.bodyMedium.copy(fontFeatureSettings = "tnum"), textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f).semantics { contentDescription = "$label: $value" })
            Box(Modifier.size(Dim.touch).pressable(enabled = value < max) { onChange((value + step).coerceAtMost(max)) }.semantics { contentDescription = "Más $label" }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Add, null, tint = if (value < max) TT.Text else TT.TextSecondary)
            }
        }
    }
}

@Composable
fun SubjectSheet(a: Academic, name: String?, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val s = name?.let { n -> Cal.subjList(a).firstOrNull { it.name == n } }
    var n by remember { mutableStateOf(s?.name ?: "") }
    var teacher by remember { mutableStateOf(s?.teacher ?: "") }
    var room by remember { mutableStateOf(s?.room ?: "") }
    var color by remember { mutableStateOf(s?.color ?: PALETTE[(Cal.subjList(a).size + 2) % PALETTE.size]) }
    var confirmDel by remember { mutableStateOf(false) }
    val dup = s == null && n.isNotBlank() && Cal.subjList(a).any { it.name == n.trim() }
    FrostSheet(onDismiss, if (s != null) "Asignatura" else "Nueva asignatura", primary = if (s != null) "Guardar" else "Crear asignatura",
        primaryEnabled = n.isNotBlank() && !dup, onPrimary = {
            AcademicRepo.edit { Edits.saveSubject(it, s?.name, n.trim(), teacher.trim(), room.trim(), color.ifEmpty { PALETTE[7] }) }
            nav.show(if (s != null) "Asignatura guardada" else "Asignatura creada"); onDismiss()
        }) {
        LabeledField("Nombre", n, { n = it.take(80) }, placeholder = "Ej. Geografía", error = if (dup) "Ya tienes esa asignatura." else null)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LabeledField("Profesor", teacher, { teacher = it.take(60) }, Modifier.weight(1f))
            LabeledField("Aula", room, { room = it.take(30) }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        ColorChooser(color, allowNone = false) { color = it }
        if (s != null) {
            Spacer(Modifier.height(20.dp))
            PillButton("Eliminar asignatura", { confirmDel = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger, icon = Icons.Rounded.Delete)
        }
    }
    if (confirmDel && s != null) ConfirmDialog("Eliminar asignatura", "Se quitará también de tu horario (y sus protecciones vinculadas). Tus exámenes y sesiones de estudio se conservan.", "Eliminar",
        onConfirm = { AcademicRepo.edit { Edits.deleteSubject(it, s.name) }; confirmDel = false; nav.show("Asignatura eliminada"); onDismiss() },
        onDismiss = { confirmDel = false })
}

@Composable
fun SlotSheet(a: Academic, slot: JornadaItem.Slot, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    var start by remember { mutableStateOf(slot.start) }
    var end by remember { mutableStateOf(slot.end) }
    var confirmDel by remember { mutableStateOf(false) }
    val bad = end <= start
    FrostSheet(onDismiss, if (slot.isBreak) "Recreo" else "Hueco de clase", primary = "Guardar", primaryEnabled = !bad, onPrimary = {
        AcademicRepo.edit { Edits.editSlot(it, slot.id, start, end) }; nav.show("Horas cambiadas"); onDismiss()
    }) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TimeField("Empieza", start, Modifier.weight(1f), allowEmpty = false) { start = it }
            TimeField("Termina", end, Modifier.weight(1f), allowEmpty = false) { end = it }
        }
        if (bad) Text("La hora de fin debe ser posterior.", style = Type.label.copy(color = TT.Danger), modifier = Modifier.padding(top = 6.dp))
        Text("Las clases de este hueco (y sus protecciones vinculadas) se mueven con él.", style = Type.label, modifier = Modifier.padding(top = 10.dp))
        Spacer(Modifier.height(20.dp))
        PillButton("Quitar este hueco", { confirmDel = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger)
    }
    if (confirmDel) ConfirmDialog("Quitar hueco", "Se quitarán también las clases que hay en él.", "Quitar",
        onConfirm = { AcademicRepo.edit { Edits.deleteSlot(it, slot.id) }; confirmDel = false; nav.show("Hueco quitado"); onDismiss() },
        onDismiss = { confirmDel = false })
}

@Composable
fun AddSlotSheet(a: Academic, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ss = Cal.slots(a); val last = ss.lastOrNull()
    val st = last?.let { Cal.toMin(it.end) } ?: 480
    val du = last?.let { Cal.toMin(it.end) - Cal.toMin(it.start) } ?: 60
    var isBreak by remember { mutableStateOf(false) }
    var start by remember { mutableStateOf(Cal.fmMin(st)) }
    var end by remember { mutableStateOf(Cal.fmMin(st + du)) }
    FrostSheet(onDismiss, "Añadir hueco", primary = "Añadir", primaryEnabled = end > start, onPrimary = {
        AcademicRepo.edit { Edits.addSlot(it, isBreak, start, end) }; nav.show("Hueco añadido"); onDismiss()
    }) {
        Segmented(listOf("Clase", "Recreo"), if (isBreak) 1 else 0, { isBreak = it == 1 }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TimeField("Empieza", start, Modifier.weight(1f), allowEmpty = false) { start = it }
            TimeField("Termina", end, Modifier.weight(1f), allowEmpty = false) { end = it }
        }
    }
}
