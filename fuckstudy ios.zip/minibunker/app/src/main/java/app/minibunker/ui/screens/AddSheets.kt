package app.minibunker.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.link.Links
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.FrostSheet
import app.minibunker.ui.frost.MenuOption
import app.minibunker.ui.theme.*
import app.minibunker.ui.frost.anchorBounds
import app.minibunker.ui.frost.FrostMenu
import app.thinktwice.core.AppState
import app.thinktwice.data.Store
import java.time.LocalDate

/* ═════════════════════════ Evento ═════════════════════════ */

class EventDraft(e: Event, tt: AppState) {
    val id = e.id
    var title by mutableStateOf(e.title)
    var date by mutableStateOf(e.date)
    var time by mutableStateOf(e.time)
    var end by mutableStateOf(e.end)
    var color by mutableStateOf(e.color)
    var cat by mutableStateOf(e.cat)
    var repeat by mutableStateOf(e.repeat)
    var note by mutableStateOf(e.note)
    var more by mutableStateOf(e.note.isNotEmpty() || e.repeat != "none" || e.cat != "personal")
    private val link = tt.routines.firstOrNull { it.link == Links.eventKey(e.id) }
    var protect by mutableStateOf(link != null && link.enabled)
    var apps by mutableStateOf(link?.packages ?: tt.templates.firstOrNull { it.id == "t_focus" }?.packages ?: emptySet())
    val hasWindow get() = time.isNotEmpty() && end.isNotEmpty() && end > time
    val valid get() = title.isNotBlank() && (!protect || !hasWindow || apps.isNotEmpty())

    fun toEvent() = Event(id, date, time, if (end.isNotEmpty() && (time.isEmpty() || end < time)) "" else end, title.trim(), note.trim(), cat, repeat, color)

    /** Guarda el evento y crea, actualiza o quita su regla vinculada (una sola por evento). */
    fun save() {
        AcademicRepo.edit { Edits.upsertEvent(it, toEvent()) }
        val now = AcademicRepo.state.value.academic
        Store.update { s ->
            s.copy(routines = if (protect && hasWindow && apps.isNotEmpty()) Links.upsert(now, s.routines, Links.eventKey(id), apps) { Store.newId() }
            else Links.remove(s.routines, Links.eventKey(id)))
        }
    }
}

@Composable
fun EventForm(tt: AppState, d: EventDraft) {
    LabeledField("¿Qué es?", d.title, { d.title = it.take(140) }, placeholder = "Ej. Estudiar en la biblioteca")
    Spacer(Modifier.height(16.dp))
    DayChooser(d.date) { d.date = it }
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) { TimeField("Hora (opcional)", d.time) { d.time = it } }
        Column(Modifier.weight(1f)) { TimeField("Hasta", d.end) { d.end = it } }
    }
    Spacer(Modifier.height(16.dp))
    ColorChooser(d.color) { d.color = it }
    Spacer(Modifier.height(12.dp))
    if (!d.more) SmallPill("Más opciones", { d.more = true }, Icons.Rounded.ExpandMore)
    else {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MenuField("Tipo", CATS.map { MenuOption(it.first, it.second) }, d.cat, Modifier.weight(1f)) { d.cat = it }
            MenuField("Repetir", REPEATS.map { MenuOption(it.first, it.second) }, d.repeat, Modifier.weight(1f)) { d.repeat = it }
        }
        Spacer(Modifier.height(12.dp))
        LabeledField("Notas", d.note, { d.note = it.take(500) }, singleLine = false, placeholder = "Lugar, detalles…")
    }
    Spacer(Modifier.height(18.dp))
    ProtectionChooser(tt, "Vincular protección",
        when (d.repeat) { "none" -> "Pausa las apps elegidas solo en esa fecha y franja"; else -> "Pausa las apps elegidas en cada repetición" },
        d.protect, { d.protect = it }, d.apps, { d.apps = it },
        unavailableReason = if (!d.hasWindow) "Pon hora de inicio y de fin para poder protegerlo" else null)
}

@Composable
fun EventSheet(tt: AppState, ac: AcadState, id: String?, date: String?, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val e = id?.let { x -> ac.academic.events.firstOrNull { it.id == x } }
    if (id != null && e == null) { LaunchedEffect(Unit) { onDismiss() }; return }
    val d = remember(id) { EventDraft(e ?: Event(newUid(), date ?: Cal.iso(LocalDate.now())), tt) }
    var confirmDel by remember { mutableStateOf(false) }
    FrostSheet(onDismiss, if (e != null) "Editar evento" else "Nuevo evento", primary = if (e != null) "Guardar" else "Añadir evento", primaryEnabled = d.valid,
        onPrimary = { d.save(); nav.show(if (e != null) "Evento guardado" else "Evento añadido"); nav.agendaDay = d.date; onDismiss() }) {
        EventForm(tt, d)
        if (e != null) {
            Spacer(Modifier.height(20.dp))
            PillButton("Eliminar evento", { confirmDel = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger, icon = Icons.Rounded.Delete)
        }
    }
    if (confirmDel && e != null) ConfirmDialog("Eliminar evento", if (e.repeat != "none") "Se eliminará con todas sus repeticiones y su protección vinculada." else "No se puede deshacer.", "Eliminar",
        onConfirm = {
            AcademicRepo.edit { Edits.deleteEvent(it, e.id) }
            Store.update { s -> s.copy(routines = Links.remove(s.routines, Links.eventKey(e.id))) }
            confirmDel = false; nav.show("Evento eliminado"); onDismiss()
        }, onDismiss = { confirmDel = false })
}

/* ═════════════════════════ Examen ═════════════════════════ */

class ExamDraft(g: Grade) {
    val id = g.id
    var subject by mutableStateOf(g.subject)
    var title by mutableStateOf(g.title)
    var date by mutableStateOf(g.date)
    var time by mutableStateOf(g.time)
    var score by mutableStateOf(g.score?.let { Cal.fmtN(it) } ?: "")
    var max by mutableStateOf(Cal.fmtN(g.max))
    var weight by mutableStateOf(g.weight?.let { Cal.fmtN(it) } ?: "")
    var note by mutableStateOf(g.note)
    var more by mutableStateOf(g.max != 10.0 || g.weight != null || g.time.isNotEmpty() || g.note.isNotEmpty())
    private fun num(s: String) = s.replace(',', '.').trim().takeIf { it.isNotEmpty() }?.toDoubleOrNull()
    val maxV get() = num(max)?.takeIf { it > 0 } ?: 10.0
    val error: String? get() = when {
        subject.isBlank() -> null
        score.isNotBlank() && num(score) == null -> "Escribe una nota válida."
        (num(score) ?: 0.0) > maxV -> "La nota no puede ser mayor que ${Cal.fmtN(maxV)}."
        (num(score) ?: 0.0) < 0 -> "La nota no puede ser negativa."
        else -> null
    }
    val valid get() = subject.isNotBlank() && error == null
    fun toGrade() = Grade(id, subject.trim(), title.trim(), date, time, num(score), maxV, num(weight), note.trim())
}

@Composable
fun ExamForm(a: Academic, d: ExamDraft) {
    // Entrada manual de asignatura (se conserva) + sugerencias + acceso evidente a TODO el catálogo.
    LabeledField("Asignatura", d.subject, { d.subject = it.take(80) }, placeholder = "Ej. Geografía")
    val catalog = subjectOptions(a)
    val sugg = catalog.map { it.value }.filter { it != d.subject && (d.subject.isBlank() || it.contains(d.subject.trim(), true)) }.take(3)
    var bounds by remember { mutableStateOf(androidx.compose.ui.geometry.Rect.Zero) }
    var all by remember { mutableStateOf(false) }
    if (catalog.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            sugg.forEach { s -> Chip(s, false, { d.subject = s }) }
            Box(Modifier.anchorBounds { bounds = it }) {
                SmallPill("Todas (${catalog.size})", { all = true }, Icons.Rounded.ExpandMore, tone = ButtonTone.Light)
            }
        }
    }
    if (all) FrostMenu(bounds, catalog, d.subject.takeIf { it.isNotBlank() }, { all = false }) { d.subject = it }
    Spacer(Modifier.height(12.dp))
    LabeledField("Examen (opcional)", d.title, { d.title = it.take(100) }, placeholder = "Ej. Tema 3")
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        DateField("Fecha", d.date, Modifier.weight(1f), allowEmpty = true) { d.date = it }
        LabeledField("Nota", d.score, { d.score = it.take(6) }, Modifier.weight(1f), numeric = true, placeholder = "Aún no")
    }
    Text(d.error ?: "Deja la nota vacía si todavía no lo has hecho.", style = Type.label.copy(color = if (d.error != null) TT.Danger else TT.TextSecondary), modifier = Modifier.padding(top = 6.dp))
    Spacer(Modifier.height(12.dp))
    if (!d.more) SmallPill("Más opciones", { d.more = true }, Icons.Rounded.ExpandMore)
    else {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LabeledField("Nota sobre", d.max, { d.max = it.take(6) }, Modifier.weight(1f), numeric = true)
            Column(Modifier.weight(1f)) { TimeField("Hora", d.time) { d.time = it } }
        }
        Spacer(Modifier.height(12.dp))
        LabeledField("Cuánto cuenta en la media (%)", d.weight, { d.weight = it.take(6) }, numeric = true, placeholder = "Igual que los demás", help = "Por ejemplo, 30 = 30 %.")
        Spacer(Modifier.height(12.dp))
        LabeledField("Comentario", d.note, { d.note = it.take(500) }, singleLine = false)
    }
}

/** Editar un examen (también desde el calendario: es el mismo examen). */
@Composable
fun ExamSheet(ac: AcadState, id: String?, date: String? = null, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val a = ac.academic
    val g = id?.let { x -> a.grades.firstOrNull { it.id == x } }
    if (id != null && g == null) { LaunchedEffect(Unit) { onDismiss() }; return }
    val d = remember(id) { ExamDraft(g ?: Grade(newUid(), date = date ?: "")) }
    var confirmDel by remember { mutableStateOf(false) }
    FrostSheet(onDismiss, if (g != null) "Editar examen" else "Nuevo examen", primary = if (g != null) "Guardar" else "Añadir examen", primaryEnabled = d.valid,
        onPrimary = { AcademicRepo.edit { Edits.upsertGrade(it, d.toGrade()) }; nav.show(if (g != null) "Examen guardado" else "Examen añadido"); onDismiss() }) {
        ExamForm(a, d)
        if (g != null) {
            val plan = Cal.planOf(a, g.id)
            Spacer(Modifier.height(20.dp))
            if (g.pending && g.date.isNotEmpty()) PillButton(if (plan.isEmpty()) "Preparar plan de estudio" else "Abrir su plan (${plan.count { it.done }}/${plan.size})",
                { nav.studySection = 1; nav.select(Tab.ESTUDIO); onDismiss() }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary, icon = Icons.Rounded.Checklist)
            Spacer(Modifier.height(Dim.related))
            PillButton("Eliminar examen", { confirmDel = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger, icon = Icons.Rounded.Delete)
        }
    }
    if (confirmDel && g != null) ConfirmDialog("Eliminar examen", "Se borrará también del calendario y su plan de estudio.", "Eliminar",
        onConfirm = { AcademicRepo.edit { Edits.deleteGrade(it, g.id) }; confirmDel = false; nav.show("Examen eliminado"); onDismiss() },
        onDismiss = { confirmDel = false })
}

/* ═════════════════════════ «Añadir» ═════════════════════════ */

/** Acción rápida de MIBUNKER: evento, examen, nota o hábito desde la misma hoja. */
@Composable
fun AddSheet(ac: AcadState, initial: AddKind, returnFocus: androidx.compose.ui.focus.FocusRequester? = null, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val tt by Store.state.collectAsState()
    var kind by remember { mutableStateOf(initial) }
    val date = remember { nav.addDate ?: Cal.iso(LocalDate.now()) }
    val ev = remember { EventDraft(Event(newUid(), date), tt) }
    val ex = remember { ExamDraft(Grade(newUid(), date = if (date >= Cal.iso(LocalDate.now())) date else "")) }
    var habit by remember { mutableStateOf("") }
    val (label, enabled) = when (kind) {
        AddKind.EVENT -> "Añadir evento" to ev.valid
        AddKind.EXAM -> "Añadir examen" to ex.valid
        AddKind.HABIT -> "Crear hábito" to habit.isNotBlank()
    }
    FrostSheet(onDismiss, "Añadir", primary = label, primaryEnabled = enabled, returnFocus = returnFocus, onPrimary = {
        when (kind) {
            AddKind.EVENT -> { ev.save(); nav.show("Evento añadido") }
            AddKind.EXAM -> { AcademicRepo.edit { Edits.upsertGrade(it, ex.toGrade()) }; nav.show("Examen añadido") }
            AddKind.HABIT -> { AcademicRepo.edit { Edits.addHabit(it, habit) }; nav.show("Hábito creado") }
        }
        onDismiss()
    }) {
        Segmented(listOf("Evento", "Examen", "Hábito"), kind.ordinal, { kind = AddKind.entries[it] }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        when (kind) {
            AddKind.EVENT -> EventForm(tt, ev)
            AddKind.EXAM -> ExamForm(ac.academic, ex)
            AddKind.HABIT -> LabeledField("¿Qué quieres hacer cada día?", habit, { habit = it.take(50) }, placeholder = "Ej. Leer 20 minutos",
                help = "Se marca a mano cada día. Los retos de thinktwice tienen sus propias reglas, medidas por el móvil.")
        }
    }
}
