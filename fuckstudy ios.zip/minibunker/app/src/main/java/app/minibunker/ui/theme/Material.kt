package app.minibunker.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.addOutline
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

/**
 * Material de superficie con el color de Apariencia (acento global) y la «Intensidad del vidrio».
 *
 * Dos familias, como en la guía de materiales de iOS 27:
 *  - Tarjetas de lectura ([cardMaterial]): fondo esmerilado teñido con el acento en toda la superficie,
 *    base suficiente para leer sobre un calendario lleno y un reflejo interior tenue.
 *  - Vidrio interactivo ([glass], usado por Modifier.frosted): cápsula, selector, menús y hojas, con más
 *    profundidad (desenfoque del contenido posterior, refracción leve en el perímetro, reflejo localizado).
 *
 * La intensidad (0 = más transparente, 1 = más tintado) solo cambia la opacidad y la proporción de tinte,
 * no el color. Los dos extremos conservan una base mínima para leer. Con contraste elevado
 * ([ThemeState.solid]) la base se vuelve casi opaca y desaparecen reflejos y refracción.
 *
 * Profundidad: dentro de otro panel translúcido (una hoja o una tarjeta) el tinte se modula a la baja
 * para que las dos capas juntas no se vuelvan opacas. Como los colores se leen de ThemeState en cada
 * dibujo, al cambiar el acento o la intensidad se actualizan también las superficies ya abiertas.
 */
val LocalMaterialDepth = compositionLocalOf { 0 }

object AccentMaterial {
    /** Menos tinte con acentos muy claros o muy oscuros: texto, iconos y selección siguen distinguiéndose. */
    private fun strength(): Float { val l = TT.Accent.luminance(); return if (l > 0.72f || l < 0.06f) 0.7f else 1f }
    private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t
    private val t get() = ThemeState.glass.coerceIn(0f, 1f)
    private val solid get() = ThemeState.solid

    /** Superficie de lectura (tarjetas, grupos, fichas, bloques, panel del calendario). */
    fun surface(depth: Int): Color {
        val s = strength()
        if (solid) return lerp(TT.Card, TT.Accent, (if (TT.isDark) 0.16f else 0.10f) * s).copy(alpha = 0.98f)
        return if (depth <= 0) {
            val k = if (TT.isDark) mix(0.12f, 0.28f, t) else mix(0.08f, 0.24f, t)
            val a = if (TT.isDark) mix(0.72f, 0.95f, t) else mix(0.70f, 0.94f, t)
            lerp(TT.Card, TT.Accent, k * s).copy(alpha = a)
        } else {
            val k = mix(0.08f, 0.18f, t)
            val a = if (TT.isDark) mix(0.30f, 0.55f, t) else mix(0.40f, 0.62f, t)
            lerp(TT.Card, TT.Accent, k * s).copy(alpha = a)
        }
    }

    /**
     * Tinte del vidrio para hojas, desplegables y cápsula (se compone sobre el desenfoque).
     * [dense]: hojas con formularios, con una base más densa para facilitar la lectura.
     */
    fun glass(dense: Boolean = false): Color {
        val base = TT.Glass
        if (solid) return lerp(TT.GlassOpaque, TT.Accent.copy(alpha = TT.GlassOpaque.alpha), 0.12f * strength())
        val a = (mix(0.56f, 0.88f, t) + if (dense) 0.08f else 0f).coerceAtMost(0.95f)
        return lerp(base.copy(alpha = a), TT.Accent.copy(alpha = a), mix(0.14f, 0.32f, t) * strength())
    }

    /** Misma superficie, más opaca, para equipos sin desenfoque fluido (Android 8–11 o poca memoria). */
    fun glassOpaque(): Color {
        val a = if (solid) 0.98f else mix(0.90f, 0.97f, t)
        return lerp(TT.GlassOpaque.copy(alpha = a), TT.Accent.copy(alpha = a), (if (solid) 0.12f else mix(0.12f, 0.26f, t)) * strength())
    }

    /** Intensidad del reflejo interior y del canto (0 con contraste elevado). */
    fun sheen(): Float = if (solid) 0f else if (TT.isDark) 0.10f else 0.45f
}

@Composable fun materialSurface(): Color = AccentMaterial.surface(LocalMaterialDepth.current)

/**
 * Tarjeta esmerilada teñida: 1) base translúcida con el acento en toda la superficie, 2) reflejo
 * interior tenue arriba, 3) canto con un brillo suave arriba y una sombra tenue abajo para separar
 * la tarjeta del fondo aunque este sea uniforme. El contenido se dibuja después, nítido.
 */
fun Modifier.cardMaterial(shape: Shape, depth: Int): Modifier = this.drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    val path = Path().apply { addOutline(outline) }
    drawPath(path, AccentMaterial.surface(depth))
    val sh = AccentMaterial.sheen()
    if (sh > 0f && depth <= 0) {
        clipPath(path) {
            // Reflejo interior: más luz arriba, desaparece antes de la mitad.
            drawRect(Brush.verticalGradient(0f to Color.White.copy(alpha = sh * 0.55f), 0.45f to Color.Transparent, endY = size.height))
        }
        glassEdge(path, sh)
    }
}

/** Canto del material: brillo arriba, sombra tenue abajo, sin anillo luminoso uniforme. */
fun DrawScope.glassEdge(path: Path, sheen: Float) {
    val w = 1.dp.toPx()
    drawPath(
        path,
        Brush.verticalGradient(
            0f to Color.White.copy(alpha = (sheen * 1.4f).coerceAtMost(0.5f)),
            0.35f to Color.White.copy(alpha = sheen * 0.25f),
            0.7f to Color.Transparent,
            1f to Color.Black.copy(alpha = if (TT.isDark) 0.35f else 0.08f),
            startY = 0f, endY = size.height,
        ),
        style = Stroke(w),
    )
}

/** Reflejo localizado del vidrio interactivo (arriba a la izquierda), sin animación en reposo. */
fun DrawScope.glassHighlight(sheen: Float) {
    val r = maxOf(size.width, size.height) * 0.55f
    val c = Offset(size.width * 0.22f, 0f)
    drawCircle(Brush.radialGradient(0f to Color.White.copy(alpha = sheen * 0.6f), 1f to Color.Transparent, center = c, radius = r), radius = r, center = c)
}
