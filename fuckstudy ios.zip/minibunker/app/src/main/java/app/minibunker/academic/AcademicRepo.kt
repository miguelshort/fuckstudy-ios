package app.minibunker.academic

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.util.Log
import app.minibunker.cloud.*
import app.minibunker.json.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.Executors

enum class SyncStatus { LOCAL, CONNECTING, SYNCED, SAVING, OFFLINE, ERROR }

fun SyncStatus.text() = when (this) {
    SyncStatus.LOCAL -> "Guardado en este dispositivo"
    SyncStatus.CONNECTING -> "Conectando con tu cuenta…"
    SyncStatus.SYNCED -> "Sincronizado con tu cuenta"
    SyncStatus.SAVING -> "Guardando…"
    SyncStatus.OFFLINE -> "Sin conexión · se guarda en este dispositivo"
    SyncStatus.ERROR -> "No se pudo sincronizar"
}

data class AcadState(
    val academic: Academic = Academic.EMPTY,
    val account: Session? = null,
    /** Usa la agenda sin cuenta (solo en este móvil). */
    val guest: Boolean = false,
    val status: SyncStatus = SyncStatus.LOCAL,
    val pending: Int = 0,
    val lastSync: Long = 0,
    val prefs: UiPrefs = UiPrefs(),
    val lastError: String? = null,
) {
    val signedIn get() = account != null
    val needsAuth get() = account == null && !guest
}

/**
 * Repositorio académico: vista local inmediata (base + cambios pendientes), persistencia atómica
 * en el almacenamiento privado y sincronización con la cuenta de MIBUNKER cuando hay red.
 */
object AcademicRepo {
    private const val FILE = "academic.json"
    private const val ACCOUNT_FILE = "account.json"
    private val io = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val syncMutex = Mutex()
    private lateinit var dir: File
    @Volatile private var ready = false
    private var core = SyncCore()
    private var pushJob: Job? = null
    private var prefsJob: Job? = null
    private var pollJob: Job? = null

    private val _state = MutableStateFlow(AcadState())
    val state: StateFlow<AcadState> get() = _state

    fun init(c: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            dir = c.applicationContext.filesDir
            var account: Session? = null; var guest = false; var prefs = UiPrefs(); var lastSync = 0L
            runCatching {
                File(dir, ACCOUNT_FILE).takeIf { it.exists() }?.let { f -> val o = Json.obj(f.readText()); account = Session.from(o.objOrNull("session")); guest = o.bool("guest") }
            }.onFailure { Log.e("fuckstudy", "Cuenta ilegible", it) }
            runCatching {
                File(dir, FILE).takeIf { it.exists() }?.let { f ->
                    val o = Json.obj(f.readText())
                    val base = Part.entries.associateWith { p -> o.objOrNull("base")?.objs(p.key).orEmpty() }
                    val pending = o.objs("pending").mapNotNull(Op::from)
                    core = SyncCore(base, pending)
                    prefs = UiPrefs.from(o.objOrNull("prefs")) ?: UiPrefs()
                    lastSync = o.long("lastSync")
                }
            }.onFailure { Log.e("fuckstudy", "Datos académicos ilegibles; se conserva copia", it); runCatching { File(dir, FILE).copyTo(File(dir, "$FILE.corrupt"), true) } }
            _state.value = AcadState(Academic(core.view()), account, guest, if (account != null) SyncStatus.CONNECTING else SyncStatus.LOCAL,
                core.pendingCount(), lastSync, prefs)
            ready = true
        }
        registerNetwork(c.applicationContext)
        if (_state.value.signedIn) syncSoon(0)
    }

    // ───────────── Cambios locales ─────────────

    /** Aplica cambios académicos al momento (sin esperar a la red) y programa el envío. */
    fun apply(changes: Changes) {
        if (changes.isEmpty()) return
        var any = false
        changes.forEach { (part, list) -> if (core.mutate(part) { list }.isNotEmpty()) any = true }
        if (!any) return
        publish()
        persist()
        if (_state.value.signedIn) { set { it.copy(status = SyncStatus.SAVING) }; syncSoon(600) }
    }

    /** Edición basada en el estado actual (evita carreras con una sincronización en curso). */
    fun edit(f: (Academic) -> Changes) = apply(f(Academic(core.view())))

    fun setPrefs(p: UiPrefs) {
        val np = p.copy(updated = System.currentTimeMillis())
        set { it.copy(prefs = np) }; persist()
        val acc = _state.value.account ?: return
        prefsJob?.cancel()
        prefsJob = scope.launch {
            delay(500)
            runCatching { remote(acc).putUnconditional("prefs", np.toJson()) }
        }
    }

    // ───────────── Cuenta ─────────────

    fun continueAsGuest() { set { it.copy(guest = true, status = SyncStatus.LOCAL) }; persistAccount() }
    /** Desde Perfil (sin cuenta): vuelve a la pantalla de acceso conservando lo que hay en el móvil. */
    fun showAuth() { set { it.copy(guest = false) }; persistAccount() }

    /** Inicia sesión o crea la cuenta. Lo usado sin cuenta en este móvil se añade a la cuenta sin borrar nada. */
    suspend fun signIn(email: String, password: String, create: Boolean, name: String) = withContext(Dispatchers.IO) {
        val s = if (create) FirebaseAuthRest.signUp(email, password, name) else FirebaseAuthRest.signIn(email, password)
        val hadGuestData = !Academic(core.view()).isEmpty
        if (hadGuestData) core.promoteAllToPending()
        set { it.copy(account = s, guest = false, status = SyncStatus.CONNECTING, pending = core.pendingCount(), lastError = null) }
        persistAccount(); persist(); publish()
        sync()
        hadGuestData
    }

    suspend fun sendReset(email: String) = withContext(Dispatchers.IO) { FirebaseAuthRest.sendPasswordReset(email) }

    /** Cierra sesión: los datos siguen en la cuenta; en este móvil se borra la copia académica. */
    fun logout() {
        pollJob?.cancel(); pushJob?.cancel()
        core.clear()
        set { AcadState(prefs = it.prefs) }
        persistAccount(); persist(); publish()
    }

    /** Borra todos los documentos de la cuenta y la propia cuenta. Necesita conexión. */
    suspend fun deleteAccount() = withContext(Dispatchers.IO) {
        val s = freshSession()
        val r = FirestoreRest(s.uid) { s.idToken }
        (Part.entries.map { it.key } + listOf("meta", "prefs")).forEach { runCatching { r.delete(it) } }
        FirebaseAuthRest.deleteAccount(s.idToken)
        logout()
    }

    // ───────────── Sincronización ─────────────

    fun syncSoon(delayMs: Long) {
        if (!_state.value.signedIn) return
        pushJob?.cancel()
        pushJob = scope.launch { delay(delayMs); sync() }
    }

    /** Mientras la app está a la vista se consulta la cuenta cada minuto (la web lo hace cada 30 s). */
    fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch { while (isActive) { if (_state.value.signedIn) sync(); delay(60_000) } }
    }
    fun stopPolling() { pollJob?.cancel(); pollJob = null }

    suspend fun sync() {
        if (!_state.value.signedIn) return
        syncMutex.withLock {
            val acc = _state.value.account ?: return
            if (_state.value.status != SyncStatus.SAVING) set { it.copy(status = SyncStatus.CONNECTING) }
            try {
                val r = remote(acc)
                val docs = SyncEngine.pull(core, r)
                SyncEngine.ensureMeta(r, docs)
                UiPrefs.from(docs["prefs"]?.value, _state.value.prefs.glass)?.let { rp -> if (rp.updated > _state.value.prefs.updated) set { it.copy(prefs = rp) } }
                publish()
                val ok = SyncEngine.pushAll(core, r)
                publish()
                set { it.copy(status = if (ok && core.pendingCount() == 0) SyncStatus.SYNCED else SyncStatus.ERROR, lastSync = System.currentTimeMillis(), lastError = null) }
                persist()
            } catch (e: NetworkException) {
                set { it.copy(status = SyncStatus.OFFLINE) }
            } catch (e: AuthException) {
                set { it.copy(status = SyncStatus.ERROR, lastError = e.message) }
            } catch (e: RemoteException) {
                set { it.copy(status = SyncStatus.ERROR, lastError = e.message) }
            } catch (e: Exception) {
                Log.e("fuckstudy", "Sincronización", e)
                set { it.copy(status = SyncStatus.ERROR, lastError = e.message) }
            }
        }
    }

    private fun freshSession(): Session {
        val s = _state.value.account ?: throw AuthException("AUTH", "No has iniciado sesión.")
        if (s.exp > System.currentTimeMillis()) return s
        val n = FirebaseAuthRest.refresh(s)
        set { it.copy(account = n) }; persistAccount()
        return n
    }

    private fun remote(acc: Session): AcademicRemote = FirestoreRest(acc.uid) { freshSession().idToken }

    private fun registerNetwork(c: Context) {
        runCatching {
            c.getSystemService(ConnectivityManager::class.java)?.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { if (_state.value.signedIn) syncSoon(800) }
            })
        }
    }

    // ───────────── Estado y disco ─────────────

    private fun set(f: (AcadState) -> AcadState) = synchronized(_state) { _state.value = f(_state.value) }

    private fun publish() = set { it.copy(academic = Academic(core.view()), pending = core.pendingCount()) }

    private fun persist() {
        if (!ready) return
        val snapshot = linkedMapOf<String, Any?>(
            "base" to core.base.mapKeys { it.key.key },
            "pending" to core.pending.map { it.toJson() },
            "prefs" to _state.value.prefs.toJson(),
            "lastSync" to _state.value.lastSync,
        )
        io.execute { atomicWrite(File(dir, FILE), Json.write(snapshot)) }
    }

    private fun persistAccount() {
        if (!ready) return
        val st = _state.value
        val o = linkedMapOf<String, Any?>("session" to st.account?.toJson(), "guest" to st.guest)
        io.execute { atomicWrite(File(dir, ACCOUNT_FILE), Json.write(o)) }
    }

    private fun atomicWrite(f: File, text: String) {
        try {
            val tmp = File(f.path + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) { Log.e("fuckstudy", "No se pudo guardar ${f.name}", e) }
    }
}
