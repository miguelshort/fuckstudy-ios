package app.minibunker.academic

import app.minibunker.json.JObj

/**
 * Cambios académicos como funciones puras: reciben el estado y devuelven las partes nuevas.
 * El repositorio las aplica con SyncCore.mutate, que genera solo los cambios por elemento.
 * Reproducen las reglas de MIBUNKER (cascadas al renombrar asignaturas, borrar exámenes, etc.).
 */
typealias Changes = Map<Part, List<JObj>>

object Edits {

    private fun <T> replaceOrAdd(list: List<T>, item: T, same: (T) -> Boolean): List<T> =
        if (list.any(same)) list.map { if (same(it)) item else it } else list + item

    // ───── Eventos ─────
    fun upsertEvent(a: Academic, e: Event): Changes {
        val fixed = if (e.end.isNotEmpty() && (e.time.isEmpty() || e.end < e.time)) e.copy(end = "") else e
        return mapOf(Part.EVENTS to replaceOrAdd(a.events, fixed) { it.id == e.id }.map { it.toJson() })
    }
    fun deleteEvent(a: Academic, id: String): Changes = mapOf(Part.EVENTS to a.events.filter { it.id != id }.map { it.toJson() })

    // ───── Exámenes y planes ─────
    fun upsertGrade(a: Academic, g: Grade): Changes = mapOf(Part.GRADES to replaceOrAdd(a.grades, g) { it.id == g.id }.map { it.toJson() })
    /** Borrar un examen borra también su plan (como en MIBUNKER). */
    fun deleteGrade(a: Academic, id: String): Changes = mapOf(
        Part.GRADES to a.grades.filter { it.id != id }.map { it.toJson() },
        Part.PLANS to a.plans.filter { it.gid != id }.map { it.toJson() },
    )
    fun replacePlan(a: Academic, gid: String, items: List<PlanItem>): Changes =
        mapOf(Part.PLANS to (a.plans.filter { it.gid != gid } + items).map { it.toJson() })
    fun setPlanDone(a: Academic, id: String, done: Boolean): Changes =
        mapOf(Part.PLANS to a.plans.map { if (it.id == id) it.copy(done = done) else it }.map { it.toJson() })

    // ───── Sesiones de estudio ─────
    /** Inserta o actualiza por id: registrar dos veces la misma sesión nunca la duplica. */
    fun upsertSession(a: Academic, s: StudySession): Changes =
        mapOf(Part.SESSIONS to replaceOrAdd(a.sessions, s) { it.id == s.id }.map { it.toJson() })

    // ───── Notas ─────
    fun upsertNote(a: Academic, n: Note): Changes =
        if (n.isEmpty) deleteNote(a, n.id) else mapOf(Part.NOTES to replaceOrAdd(a.notes, n) { it.id == n.id }.map { it.toJson() })
    fun deleteNote(a: Academic, id: String): Changes = mapOf(Part.NOTES to a.notes.filter { it.id != id }.map { it.toJson() })
    fun toggleNoteItem(a: Academic, noteId: String, itemId: String): Changes = mapOf(Part.NOTES to a.notes.map { n ->
        if (n.id != noteId) n else n.copy(items = n.items.map { if (it.id == itemId) it.copy(done = !it.done) else it }, updated = System.currentTimeMillis())
    }.map { it.toJson() })

    // ───── Hábitos ─────
    fun addHabit(a: Academic, name: String): Changes =
        mapOf(Part.HABITS to (a.habits + Habit(newUid(), name.trim(), PALETTE[(a.habits.size + 2) % PALETTE.size])).map { it.toJson() })
    fun toggleHabit(a: Academic, id: String, date: String): Changes = mapOf(Part.HABITS to a.habits.map { h ->
        if (h.id != id) h else h.copy(days = if (h.done(date)) h.days - date else h.days + (date to 1))
    }.map { it.toJson() })
    fun deleteHabit(a: Academic, id: String): Changes = mapOf(Part.HABITS to a.habits.filter { it.id != id }.map { it.toJson() })

    // ───── Asignaturas ─────
    /** Crea o edita una asignatura. Al renombrarla se actualiza en horario, exámenes, sesiones y planes. */
    fun saveSubject(a: Academic, oldName: String?, name: String, teacher: String, room: String, color: String): Changes {
        val out = mutableMapOf<Part, List<JObj>>()
        if (oldName == null) {
            out[Part.SUBJECTS] = (a.subjects + Subject(newUid(), name, teacher, room, color)).map { it.toJson() }
            return out
        }
        val real = a.subjects.firstOrNull { it.name == oldName }
        out[Part.SUBJECTS] = (if (real != null) a.subjects.map { if (it.name == oldName) it.copy(name = name, teacher = teacher, room = room, color = color) else it }
        else a.subjects + Subject(newUid(), name, teacher, room, color)).map { it.toJson() }
        out[Part.TIMETABLE] = a.timetable.map { if (it.subject == oldName) it.copy(subject = name, teacher = teacher, room = room, color = color) else it }.map { it.toJson() }
        if (name != oldName) {
            out[Part.GRADES] = a.grades.map { if (it.subject == oldName) it.copy(subject = name) else it }.map { it.toJson() }
            out[Part.SESSIONS] = a.sessions.map { if (it.subject == oldName) it.copy(subject = name) else it }.map { it.toJson() }
            out[Part.PLANS] = a.plans.map { if (it.subject == oldName) it.copy(subject = name) else it }.map { it.toJson() }
        }
        return out
    }
    /** Elimina la asignatura y sus huecos del horario; exámenes y sesiones se conservan. */
    fun deleteSubject(a: Academic, name: String): Changes = mapOf(
        Part.SUBJECTS to a.subjects.filter { it.name != name }.map { it.toJson() },
        Part.TIMETABLE to a.timetable.filter { it.subject != name }.map { it.toJson() },
    )

    // ───── Jornada y horario ─────

    /** Si la jornada solo existe implícita en el horario, la materializa (ensureJornada de MIBUNKER). */
    fun ensureJornada(a: Academic): Academic {
        if (a.jornada.any { it !is JornadaItem.Cfg }) return a
        val d = Cal.slots(a).mapIndexed { i, s -> JornadaItem.Slot("s${i + 1}", s.isBreak, s.start, s.end) }
        val tt = a.timetable.map { c -> d.firstOrNull { it.start == c.start && it.end == c.end }?.let { c.copy(slot = it.id) } ?: c }
        val cfg = Cal.cfg(a) ?: JornadaItem.Cfg(Cal.ttDays(a))
        return Academic(a.raw + mapOf(Part.JORNADA to (d + cfg).map { it.toJson() }, Part.TIMETABLE to tt.map { it.toJson() }))
    }

    private fun slotIdOf(a: Academic, c: ClassEntry): String? =
        c.slot.ifEmpty { null } ?: Cal.slots(a).firstOrNull { it.start == c.start && it.end == c.end }?.id

    /** Clases que se perderían al aplicar una jornada nueva (para avisar antes). */
    fun jornadaLosses(a: Academic, gen: JornadaGen, days: List<Int>): List<ClassEntry> {
        val ids = Cal.genSlots(gen).map { it.id }.toSet()
        return a.timetable.filter { c -> slotIdOf(a, c) !in ids || c.day !in days }
    }

    fun applyJornada(a: Academic, gen: JornadaGen, days: List<Int>): Changes {
        val ss = Cal.genSlots(gen); val ids = ss.associateBy { it.id }
        val lost = jornadaLosses(a, gen, days).map { it.id }.toSet()
        val tt = a.timetable.filter { it.id !in lost }.map { c -> ids[slotIdOf(a, c)]?.let { x -> c.copy(slot = x.id, start = x.start, end = x.end) } ?: c }
        return mapOf(
            Part.JORNADA to (ss + JornadaItem.Cfg(days.sorted(), gen)).map { it.toJson() },
            Part.TIMETABLE to tt.map { it.toJson() },
        )
    }

    fun editSlot(a0: Academic, slotId: String, start: String, end: String): Changes {
        val a = ensureJornada(a0)
        val sl = Cal.slots(a).firstOrNull { it.id == slotId } ?: return emptyMap()
        return mapOf(
            Part.JORNADA to a.jornada.map { if (it is JornadaItem.Slot && it.id == slotId) it.copy(start = start, end = end) else it }.map { it.toJson() },
            Part.TIMETABLE to a.timetable.map { c ->
                if (c.slot == sl.id || (c.slot.isEmpty() && c.start == sl.start && c.end == sl.end)) c.copy(slot = sl.id, start = start, end = end) else c
            }.map { it.toJson() },
        )
    }

    fun deleteSlot(a0: Academic, slotId: String): Changes {
        val a = ensureJornada(a0)
        val sl = Cal.slots(a).firstOrNull { it.id == slotId } ?: return emptyMap()
        return mapOf(
            Part.JORNADA to a.jornada.filter { it.id != slotId }.map { it.toJson() },
            Part.TIMETABLE to a.timetable.filterNot { c -> c.slot == sl.id || (c.slot.isEmpty() && c.start == sl.start && c.end == sl.end) }.map { it.toJson() },
        )
    }

    fun addSlot(a0: Academic, isBreak: Boolean, start: String, end: String): Changes {
        val a = ensureJornada(a0)
        return mapOf(Part.JORNADA to (a.jornada + JornadaItem.Slot(newUid(), isBreak, start, end)).map { it.toJson() },
            Part.TIMETABLE to a.timetable.map { it.toJson() })
    }

    /** Asigna (o vacía, con [subject] null) un hueco en uno o varios días. */
    fun setCells(a0: Academic, days: List<Int>, slot: JornadaItem.Slot, subject: String?): Changes {
        var a = a0
        var sl = slot
        if (sl.id.isEmpty() || sl.id.startsWith("d")) {
            a = ensureJornada(a)
            sl = Cal.slots(a).firstOrNull { it.start == slot.start && it.end == slot.end } ?: slot
        }
        var tt = a.timetable
        val s = subject?.let { n -> Cal.subjList(a).firstOrNull { it.name == n } ?: Subject("", n, color = Cal.subjColor(a, n)) }
        days.forEach { day ->
            val e = tt.firstOrNull { it.day == day && (if (it.slot.isNotEmpty()) it.slot == sl.id else it.start == sl.start && it.end == sl.end) }
            tt = if (s == null) tt.filter { it !== e }
            else {
                val o = ClassEntry(e?.id ?: newUid(), day, sl.start, sl.end, sl.id, s.name, s.teacher, s.room, s.color.ifEmpty { Cal.subjColor(a, s.name) })
                if (e != null) tt.map { if (it === e) o else it } else tt + o
            }
        }
        return mapOf(Part.TIMETABLE to tt.map { it.toJson() }, Part.JORNADA to a.jornada.map { it.toJson() })
    }
}
