package app.minibunker.academic

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min

/** Cálculos académicos de MIBUNKER portados a Kotlin (misma semántica que el index.html). */
object Cal {
    val MESES = listOf("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
    val DIAS = listOf("domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado")
    val DAYN = listOf("Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado")
    val es: Locale = Locale("es", "ES")

    fun iso(d: LocalDate): String = d.toString()
    fun parse(s: String): LocalDate? = runCatching { LocalDate.parse(s) }.getOrNull()
    fun addD(s: String, n: Long): String = (parse(s) ?: LocalDate.now()).plusDays(n).toString()
    /** Día de la semana como getDay() de JS: 0 = domingo. */
    fun jsDay(d: LocalDate): Int = d.dayOfWeek.value % 7
    fun isoDayFromJs(js: Int): Int = if (js == 0) 7 else js
    fun toMin(t: String): Int { val p = t.split(":"); return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0) }
    fun fmMin(m: Int): String { val x = m.coerceIn(0, 1439); return "%02d:%02d".format(x / 60, x % 60) }
    fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    fun fmtDur(min: Int): String { val h = min / 60; val m = min % 60; return if (h > 0) "$h h" + (if (m > 0) " $m min" else "") else "$m min" }
    fun fmtN(n: Double?): String {
        if (n == null || n.isNaN()) return "–"
        val r = Math.round(n * 100) / 100.0
        return if (r == floor(r)) r.toLong().toString() else ("%.2f".format(Locale.US, r).trimEnd('0').trimEnd('.')).replace('.', ',')
    }
    fun fmtD(s: String): String = parse(s)?.format(DateTimeFormatter.ofPattern("dd/MM/yy")) ?: "Sin fecha"
    fun longDate(d: LocalDate) = "${cap(DIAS[jsDay(d)])} ${d.dayOfMonth} de ${MESES[d.monthValue - 1]}"
    fun shortMonth(d: LocalDate) = MESES[d.monthValue - 1].take(3)

    fun rel(d: String, today: LocalDate = LocalDate.now()): String {
        val x = parse(d) ?: return ""
        val diff = java.time.temporal.ChronoUnit.DAYS.between(today, x)
        return when { diff == 0L -> "Hoy"; diff == 1L -> "Mañana"; diff == -1L -> "Ayer"; diff > 1 -> "En $diff días"; else -> "Hace ${-diff} días" }
    }
    fun shortDay(ds: String, today: LocalDate = LocalDate.now()): String {
        if (ds == iso(today)) return "Hoy"; if (ds == iso(today.plusDays(1))) return "Mañana"
        val d = parse(ds) ?: return ds; return DIAS[jsDay(d)].take(3) + " " + d.dayOfMonth
    }

    // ───── Eventos ─────

    fun occurs(e: Event, d: String): Boolean {
        if (d < e.date) return false
        if (e.repeat == "none" || e.repeat.isEmpty()) return d == e.date
        val a = parse(e.date) ?: return false; val b = parse(d) ?: return false
        return when (e.repeat) {
            "daily" -> true
            "weekly" -> a.dayOfWeek == b.dayOfWeek
            "monthly" -> a.dayOfMonth == b.dayOfMonth
            "yearly" -> a.dayOfMonth == b.dayOfMonth && a.month == b.month
            else -> false
        }
    }

    /** Elemento del día: evento propio o examen fechado (el MISMO examen, editable). */
    sealed interface DayItem {
        val time: String
        val title: String
        data class Ev(val e: Event) : DayItem { override val time get() = e.time; override val title get() = e.title }
        data class Exam(val g: Grade) : DayItem {
            override val time get() = g.time
            override val title get() = "Examen de ${g.subject}" + if (g.title.isNotEmpty()) " · ${g.title}" else ""
        }
    }

    fun dayItems(a: Academic, d: String): List<DayItem> =
        (a.events.filter { occurs(it, d) }.map { DayItem.Ev(it) } + a.grades.filter { it.date == d }.distinctBy { it.id }.map { DayItem.Exam(it) })
            .sortedBy { it.time.ifEmpty { "99" } }

    // ───── Horario ─────

    fun classesOnDay(a: Academic, jsDay: Int) = a.timetable.filter { it.day == jsDay }.sortedBy { it.start }
    fun classesOn(a: Academic, d: LocalDate) = classesOnDay(a, jsDay(d))

    fun cfg(a: Academic): JornadaItem.Cfg? = a.jornada.filterIsInstance<JornadaItem.Cfg>().firstOrNull()
    fun ttDays(a: Academic): List<Int> {
        cfg(a)?.days?.takeIf { it.isNotEmpty() }?.let { return it.sorted() }
        val d = mutableListOf(1, 2, 3, 4, 5); if (a.timetable.any { it.day == 6 }) d += 6; return d
    }
    fun slots(a: Academic): List<JornadaItem.Slot> {
        val s = a.jornada.filterIsInstance<JornadaItem.Slot>().toMutableList()
        if (s.isEmpty()) {
            val seen = HashSet<String>()
            a.timetable.forEach { c -> val k = c.start + "-" + c.end; if (seen.add(k)) s += JornadaItem.Slot("d$k", false, c.start, c.end) }
        }
        return s.sortedBy { it.start }
    }
    fun entryAt(a: Academic, day: Int, sl: JornadaItem.Slot): ClassEntry? =
        a.timetable.firstOrNull { it.day == day && (if (it.slot.isNotEmpty()) it.slot == sl.id else it.start == sl.start && it.end == sl.end) }

    fun genSlots(o: JornadaGen): List<JornadaItem.Slot> {
        var t = toMin(o.start); val out = mutableListOf<JornadaItem.Slot>()
        for (i in 1..o.n) {
            out += JornadaItem.Slot("s$i", false, fmMin(t), fmMin(t + o.dur)); t += o.dur
            if (i < o.n && o.b1 > 0 && i == o.b1a) { out += JornadaItem.Slot("r1", true, fmMin(t), fmMin(t + o.b1)); t += o.b1 }
            if (i < o.n && o.b2 > 0 && i == o.b2a) { out += JornadaItem.Slot("r2", true, fmMin(t), fmMin(t + o.b2)); t += o.b2 }
        }
        return out
    }

    /** Clave para no duplicar la misma asignatura escrita con otra mayúscula o espacios. */
    fun subjKey(n: String): String = n.trim().replace(Regex("\\s+"), " ").lowercase(es)

    /** Minutos de clase por semana de cada asignatura (duración real de cada tramo; recreos y huecos no cuentan). */
    fun weeklyMinutes(a: Academic): Map<String, Int> {
        val m = HashMap<String, Int>()
        a.timetable.forEach { c -> val d = toMin(c.end) - toMin(c.start); if (d > 0 && c.subject.isNotBlank()) m.merge(subjKey(c.subject), d, Int::plus) }
        return m
    }

    /**
     * Catálogo único de asignaturas: parte de las guardadas por el usuario (con su etiqueta y color)
     * y recupera las que solo aparecen en el horario antiguo o en los exámenes, sin duplicarlas.
     * Orden: minutos semanales de clase de mayor a menor; sin horas al final; empates por orden alfabético en español.
     */
    fun subjList(a: Academic): List<Subject> {
        val out = LinkedHashMap<String, Subject>()
        a.subjects.forEach { s -> if (s.name.isNotBlank()) out.putIfAbsent(subjKey(s.name), s.copy(name = s.name.trim())) }
        a.timetable.forEach { c -> if (c.subject.isNotBlank()) out.putIfAbsent(subjKey(c.subject), Subject("x" + c.subject.trim(), c.subject.trim(), c.teacher, c.room, c.color.ifEmpty { subjColor(a, c.subject) })) }
        a.grades.forEach { g -> if (g.subject.isNotBlank()) out.putIfAbsent(subjKey(g.subject), Subject("x" + g.subject.trim(), g.subject.trim(), color = subjColor(a, g.subject.trim()))) }
        val mins = weeklyMinutes(a); val col = java.text.Collator.getInstance(es)
        return out.values.sortedWith(compareByDescending<Subject> { mins[subjKey(it.name)] ?: 0 }.thenComparator { x, y -> col.compare(x.name, y.name) })
    }
    fun minutesOf(a: Academic, name: String) = weeklyMinutes(a)[subjKey(name)] ?: 0
    fun subjColor(a: Academic, name: String): String {
        val k = subjKey(name)
        a.subjects.firstOrNull { subjKey(it.name) == k }?.color?.takeIf { it.isNotEmpty() }?.let { return it }
        a.timetable.firstOrNull { subjKey(it.subject) == k && it.color.isNotEmpty() }?.let { return it.color }
        var h = 0; name.forEach { h = h * 31 + it.code }; return PALETTE[abs(h) % PALETTE.size]
    }
    /** Nombres del catálogo, en el mismo orden (selectores de estudio, examen y calculadora). */
    fun allSubjects(a: Academic): List<String> = subjList(a).map { it.name }

    /** Títulos breves para la cuadrícula del mes: los que caben y «+N más». Cada examen aparece una sola vez. */
    fun cellTitles(a: Academic, d: String, max: Int): Pair<List<Pair<String, Boolean>>, Int> {
        val items = dayItems(a, d).map { (if (it is DayItem.Exam) "Examen ${it.g.subject}" else it.title.ifBlank { "Evento" }) to (it is DayItem.Exam) }
        if (items.size <= max) return items to 0
        return items.take(max - 1) to items.size - (max - 1)
    }

    // ───── Exámenes ─────

    data class SubjectAvg(val name: String, val list: List<Grade>, val graded: Int, val avg: Double?)

    fun subjects(a: Academic): List<SubjectAvg> {
        val m = LinkedHashMap<String, MutableList<Grade>>()
        a.grades.forEach { g -> m.getOrPut(g.subject.trim().ifEmpty { "Sin asignatura" }) { mutableListOf() } += g }
        return m.keys.sortedWith(java.text.Collator.getInstance(es)).map { k ->
            val gr = m[k]!!.filter { it.score != null }
            var sw = 0.0; var sum = 0.0
            gr.forEach { g -> val w = if ((g.weight ?: 0.0) > 0) g.weight!! else 1.0; sw += w; sum += g.g10!! * w }
            SubjectAvg(k, m[k]!!, gr.size, if (sw > 0) sum / sw else null)
        }
    }
    fun overall(a: Academic): Double? = subjects(a).mapNotNull { it.avg }.takeIf { it.isNotEmpty() }?.average()
    fun nextExams(a: Academic, today: String) = a.grades.filter { it.score == null && it.date.isNotEmpty() && it.date >= today }.sortedBy { it.date }

    sealed interface Needed {
        /** Aún no hay exámenes de esa asignatura. */
        data object NoExams : Needed
        /** Hay exámenes, pero ninguno pendiente: la nota final ya no depende de nada. */
        data class NoPending(val current: Double?) : Needed
        data class Result(val need: Double, val max: Double, val pending: List<Grade>, val totalW: Double) : Needed
    }
    fun weight(g: Grade) = if ((g.weight ?: 0.0) > 0) g.weight!! else 1.0
    /** Calculadora «¿Qué nota necesito?» (needed de MIBUNKER). Un examen pendiente nunca cuenta como cero. */
    fun needed(a: Academic, subj: String, target: Double): Needed {
        val k = subjKey(subj)
        val list = a.grades.filter { subjKey(it.subject.ifBlank { "Sin asignatura" }) == k }
        if (list.isEmpty()) return Needed.NoExams
        val gr = list.filter { it.score != null }; val pe = list.filter { it.score == null }
        if (pe.isEmpty()) return Needed.NoPending(subjects(a).firstOrNull { subjKey(it.name) == k }?.avg)
        var wg = 0.0; var sg = 0.0; var wp = 0.0
        gr.forEach { wg += weight(it); sg += it.g10!! * weight(it) }; pe.forEach { wp += weight(it) }
        return Needed.Result((target * (wg + wp) - sg) / wp, (sg + 10 * wp) / (wg + wp), pe, wg + wp)
    }
    fun roundUp2(x: Double) = ceil(x * 100) / 100

    // ───── Planes ─────

    fun planOf(a: Academic, gid: String) = a.plans.filter { it.gid == gid }.sortedBy { it.date }

    /** Reparte los temas desde [start] hasta la víspera del examen; opcionalmente reserva el último día para repaso. */
    fun makePlan(g: Grade, topics: List<String>, start: String, review: Boolean, today: String, idGen: () -> String = ::newUid): List<PlanItem> {
        val lines = topics.map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()
        val days = mutableListOf<String>()
        var d = start
        while (d < g.date) { days += d; d = addD(d, 1) }
        if (days.isEmpty()) days += if (start < g.date) start else today
        var rd: String? = null
        if (review && days.size >= 2) rd = days.removeAt(days.lastIndex)
        val out = lines.mapIndexed { i, t ->
            PlanItem(idGen(), g.id, g.subject, t, days[min(days.size - 1, floor(i.toDouble() * days.size / lines.size).toInt())])
        }.toMutableList()
        if (rd != null) out += PlanItem(idGen(), g.id, g.subject, "Repaso general", rd, review = true)
        return out
    }

    // ───── Hábitos ─────

    fun streak(h: Habit, today: String): Int { var d = today; if (!h.done(d)) d = addD(d, -1); var n = 0; while (h.done(d)) { n++; d = addD(d, -1) }; return n }
    fun last30(h: Habit, today: String) = (0 until 30).count { h.done(addD(today, -it.toLong())) }

    // ───── Estudio ─────

    fun weekStart(today: LocalDate): LocalDate = today.with(DayOfWeek.MONDAY)
    fun minutesOn(a: Academic, d: String) = a.sessions.filter { it.date == d }.sumOf { it.mins }

    fun pendingTasks(a: Academic) = a.notes.flatMap { n -> n.items.filter { !it.done }.map { n to it } }
}
