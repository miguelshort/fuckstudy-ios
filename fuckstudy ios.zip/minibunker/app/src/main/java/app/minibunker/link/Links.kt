package app.minibunker.link

import app.minibunker.academic.*
import app.thinktwice.core.Routine
import app.thinktwice.core.Schedule

/**
 * «Vincular protección»: una clase semanal o un evento pueden llevar una rutina de thinktwice.
 * La rutina guarda en [Routine.link] el elemento de origen; cada vez que cambian los datos
 * académicos (aquí o en otro dispositivo) se recalcula su horario a partir de ese elemento.
 * Nunca se crea una segunda regla para el mismo elemento.
 */
object Links {
    fun classKey(id: String) = "class:$id"
    fun eventKey(id: String) = "event:$id"

    data class Window(val name: String, val startMin: Int, val endMin: Int, val schedule: Schedule, val days: Set<Int>, val anchorDay: Long?, val icon: String)

    /** Franja que protege una clase: su día de la semana, de su hora de inicio a la de fin. */
    fun windowFor(c: ClassEntry): Window? {
        val s = Cal.toMin(c.start); val e = Cal.toMin(c.end)
        if (e <= s) return null
        return Window("Clase · ${c.subject}", s, e, Schedule.WEEKLY, setOf(Cal.isoDayFromJs(c.day)), null, "study")
    }

    /** Franja de un evento con hora de inicio y fin. Un evento aislado protege solo su fecha. */
    fun windowFor(e: Event): Window? {
        if (e.time.isEmpty() || e.end.isEmpty()) return null
        val s = Cal.toMin(e.time); val en = Cal.toMin(e.end)
        if (en <= s) return null
        val d = Cal.parse(e.date) ?: return null
        val anchor = d.toEpochDay()
        val name = e.title.ifBlank { "Evento" }
        val icon = if (e.cat == "estudio") "study" else if (e.cat == "trabajo") "work" else "focus"
        return when (e.repeat) {
            "daily" -> Window(name, s, en, Schedule.WEEKLY, (1..7).toSet(), anchor, icon)
            "weekly" -> Window(name, s, en, Schedule.WEEKLY, setOf(d.dayOfWeek.value), anchor, icon)
            "monthly" -> Window(name, s, en, Schedule.MONTHLY, emptySet(), anchor, icon)
            "yearly" -> Window(name, s, en, Schedule.YEARLY, emptySet(), anchor, icon)
            else -> Window(name, s, en, Schedule.ONCE, emptySet(), anchor, icon)
        }
    }

    fun windowFor(a: Academic, link: String): Window? {
        val (kind, id) = link.split(":", limit = 2).let { (it.getOrNull(0) ?: "") to (it.getOrNull(1) ?: "") }
        return when (kind) {
            "class" -> a.timetable.firstOrNull { it.id == id }?.let { windowFor(it) }
            "event" -> a.events.firstOrNull { it.id == id }?.let { windowFor(it) }
            else -> null
        }
    }

    fun exists(a: Academic, link: String): Boolean {
        val (kind, id) = link.split(":", limit = 2).let { (it.getOrNull(0) ?: "") to (it.getOrNull(1) ?: "") }
        return when (kind) {
            "class" -> a.timetable.any { it.id == id }
            "event" -> a.events.any { it.id == id }
            else -> true
        }
    }

    fun apply(r: Routine, w: Window) = r.copy(name = w.name, startMin = w.startMin, endMin = w.endMin, schedule = w.schedule, days = w.days, anchorDay = w.anchorDay)

    /**
     * Ajusta las rutinas vinculadas a los datos académicos actuales.
     *  - Si el elemento ya no existe, su rutina se elimina.
     *  - Si cambió de hora, día o fecha, la rutina se mueve con él.
     *  - Si ya no tiene una franja válida (p. ej. un evento sin horas), la rutina se desactiva sin perder sus apps.
     * Si [a] está vacío (sin cuenta cargada) no se toca nada, para no borrar reglas por una carga incompleta.
     */
    fun reconcile(a: Academic, routines: List<Routine>): List<Routine> {
        if (a.isEmpty && routines.any { it.isLinked }) return routines
        val seen = HashSet<String>()
        return routines.mapNotNull { r ->
            val link = r.link ?: return@mapNotNull r
            if (!seen.add(link)) return@mapNotNull null // duplicado accidental: se conserva uno
            if (!exists(a, link)) return@mapNotNull null
            val w = windowFor(a, link)
            if (w == null) r.copy(enabled = false) else apply(r, w)
        }
    }

    /** Crea o actualiza la regla de un elemento con las apps elegidas (una sola por elemento). */
    fun upsert(a: Academic, routines: List<Routine>, link: String, packages: Set<String>, newId: () -> String): List<Routine> {
        val w = windowFor(a, link) ?: return routines
        val existing = routines.firstOrNull { it.link == link }
        return if (existing != null) routines.map { if (it.link == link) apply(it.copy(packages = packages, enabled = true), w) else it }
        else routines + apply(Routine(newId(), w.name, packages, w.startMin, w.endMin, w.days, true, w.icon, link = link), w)
    }

    fun remove(routines: List<Routine>, link: String) = routines.filter { it.link != link }
}
