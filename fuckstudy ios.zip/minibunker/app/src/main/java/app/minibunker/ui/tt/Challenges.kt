package app.minibunker.ui.tt

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.minibunker.ui.LocalNav
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class StatusLook(val symbol: String, val text: String, val color: Color, val bg: Color)

private fun look(s: DayStatus) = when (s) {
    DayStatus.MET_MEASURED -> StatusLook("✓", "Cumplido (medido)", TT.Bg, TT.Positive)
    DayStatus.MET_MANUAL -> StatusLook("✓", "Cumplido (confirmado a mano)", TT.Positive, TT.Control)
    DayStatus.MISSED_MEASURED -> StatusLook("✕", "No cumplido (medido)", TT.Bg, TT.Danger)
    DayStatus.MISSED_MANUAL -> StatusLook("✕", "No cumplido (confirmado a mano)", TT.Danger, TT.Control)
    DayStatus.PENDING -> StatusLook("·", "Pendiente", TT.TextSecondary, TT.Card)
    DayStatus.NO_DATA -> StatusLook("?", "Sin datos suficientes", TT.TextSecondary, TT.Control)
}

@Composable
fun ChallengeDetailScreen(state: AppState, id: String) {
    val nav = LocalNav.current
    val c = state.challenges.firstOrNull { it.id == id }
    if (c == null) { DetailScaffold("Reto") { item { Text("Este reto ya no existe.", style = Type.secondary) } }; return }
    val statuses = rememberChallengeStatuses(state, c)
    val days = Challenges.days(c)
    val today = LocalDate.now()
    var editing by remember { mutableStateOf<LocalDate?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val es = Locale("es", "ES")

    DetailScaffold(challengeTitle(c)) {
        item {
            Text(Challenges.ruleText(c, state.routines.firstOrNull { it.id == c.routineId }?.name), style = Type.body.copy(color = TT.TextSecondary))
            Spacer(Modifier.height(4.dp))
            Text("Del ${days.first().format(DateTimeFormatter.ofPattern("d MMM", es))} al ${days.last().format(DateTimeFormatter.ofPattern("d MMM", es))}", style = Type.label)
            Spacer(Modifier.height(20.dp))
            val met = statuses.count { it == DayStatus.MET_MEASURED || it == DayStatus.MET_MANUAL }
            Row {
                Column(Modifier.weight(1f)) { Text("$met", style = Type.cardFigure); Text("cumplidos", style = Type.label) }
                Column(Modifier.weight(1f)) { Text("${statuses.count { it == DayStatus.MISSED_MEASURED || it == DayStatus.MISSED_MANUAL }}", style = Type.cardFigure); Text("no cumplidos", style = Type.label) }
                Column(Modifier.weight(1f)) { Text("${statuses.count { it == DayStatus.NO_DATA }}", style = Type.cardFigure); Text("sin datos", style = Type.label) }
            }
        }
        item {
            SectionHeader("Calendario")
            TTCard {
                // Celdas uniformes, 7 por fila, con símbolo + texto accesible (no solo color).
                days.chunked(7).forEachIndexed { row, week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        week.forEachIndexed { i, d ->
                            val st = statuses[row * 7 + i]
                            val l = look(st)
                            val canEdit = !d.isAfter(today) && st != DayStatus.MET_MEASURED && st != DayStatus.MISSED_MEASURED
                            Column(
                                Modifier.weight(1f).aspectRatio(0.8f).clip(RoundedCornerShape(12.dp)).background(l.bg)
                                    .then(if (d == today) Modifier.border(1.5.dp, TT.Accent, RoundedCornerShape(12.dp)) else Modifier)
                                    .then(if (canEdit) Modifier.pressable { editing = d } else Modifier)
                                    .semantics(mergeDescendants = true) { contentDescription = "${d.format(DateTimeFormatter.ofPattern("EEEE d MMMM", es))}: ${l.text}" },
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                            ) {
                                Text("${d.dayOfMonth}", style = Type.label.copy(color = if (l.bg == TT.Positive || l.bg == TT.Danger) TT.Bg else TT.TextSecondary))
                                Text(l.symbol, style = Type.cardTitle.copy(color = l.color), textAlign = TextAlign.Center)
                            }
                        }
                        repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            listOf(DayStatus.MET_MEASURED, DayStatus.MET_MANUAL, DayStatus.MISSED_MEASURED, DayStatus.PENDING, DayStatus.NO_DATA).forEach {
                val l = look(it)
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(l.bg), contentAlignment = Alignment.Center) { Text(l.symbol, style = Type.label.copy(color = l.color)) }
                    Spacer(Modifier.width(8.dp)); Text(l.text, style = Type.label)
                }
            }
            Text("Los días sin datos o de hoy pueden confirmarse a mano; se muestran diferenciados de los medidos.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
        }
        item {
            SectionHeader("Opciones")
            ListGroup {
                ListRow("Recordatorio diario", "Notificación local, sin servidores", leading = { RowIcon(Icons.Rounded.Notifications) },
                    trailingSwitch = c.reminder, switchLabel = "Recordatorio diario",
                    onSwitch = { on -> Store.update { s -> s.copy(challenges = s.challenges.map { if (it.id == c.id) it.copy(reminder = on) else it }) } })
            }
            Text("Un reto no garantiza que se forme un hábito en un número fijo de días: es una forma de seguir tu compromiso.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(Dim.section))
            PillButton("Eliminar reto", { confirmDelete = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger, icon = Icons.Rounded.Delete)
        }
    }

    editing?.let { d ->
        fun set(v: Boolean?) {
            Store.update { s -> s.copy(challenges = s.challenges.map {
                if (it.id != c.id) it else it.copy(manual = if (v == null) it.manual - d.toEpochDay() else it.manual + (d.toEpochDay() to v))
            }) }
            editing = null
        }
        FrostSheet({ editing = null }, "Confirmar ${d.format(DateTimeFormatter.ofPattern("d MMM", es))}", scrollable = false, footer = {
            Spacer(Modifier.height(18.dp))
            PillButton("Cumplido", { set(true) }, Modifier.fillMaxWidth(), tone = ButtonTone.Light)
            Spacer(Modifier.height(8.dp))
            PillButton("No cumplido", { set(false) }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary)
            if (c.manual.containsKey(d.toEpochDay())) { Spacer(Modifier.height(8.dp)); PillButton("Quitar confirmación", { set(null) }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger) }
        }) {
            Text("No hay una medición automática para este día. Puedes registrarlo manualmente; se mostrará como confirmación manual.", style = Type.body.copy(color = TT.TextSecondary))
        }
    }
    if (confirmDelete) ConfirmDialog("¿Eliminar este reto?", "Se borrará su calendario y confirmaciones.", "Eliminar",
        onConfirm = { Store.update { s -> s.copy(challenges = s.challenges.filter { it.id != c.id }) }; confirmDelete = false; nav.show("Reto eliminado"); nav.pop() },
        onDismiss = { confirmDelete = false })
}
