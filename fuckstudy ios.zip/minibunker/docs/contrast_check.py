"""Contraste WCAG del texto sobre la tarjeta de lectura ya compuesta sobre el fondo de la vista.
Reproduce Palettes (Tokens.kt) y AccentMaterial.surface (Material.kt, profundidad 0) con los 8 acentos,
en claro y oscuro, con «Intensidad del vidrio» en 0, 0,5 y 1. Si cambias esos valores, actualízalos aquí.
Uso: python3 docs/contrast_check.py  (imprime FAIL por cada combinación < 4,5:1 y el peor caso)."""
acc={"azul":("6C8CFF","2D5FC7"),"lila":("A99CF5","6B57D4"),"rosa":("F29CC4","B8336F"),"verde":("65D6A0","2A6B57"),
"turquesa":("7FD3D6","136C75"),"melocoton":("F2B48C","A24C23"),"coral":("F59A92","B83A36"),"dorado":("E9CF6B","7A5E00")}
def h(x): return [int(x[i:i+2],16)/255 for i in (0,2,4)]
def lin(c): return c/12.92 if c<=0.03928 else ((c+0.055)/1.055)**2.4
def L(c): r,g,b=[lin(v) for v in c]; return .2126*r+.7152*g+.0722*b
def lerp(a,b,t): return [x+(y-x)*t for x,y in zip(a,b)]
def cr(a,b): la,lb=sorted([L(a),L(b)]); return (lb+.05)/(la+.05)
def mix(a,b,t): return a+(b-a)*t
worst={}
for dark in (True,False):
  bg=h("0B0C0F" if dark else "F3F4F7"); card=h("1E2128" if dark else "FFFFFF")
  text=h("F7F8FA" if dark else "0E1014"); sec=h("BFC4CD" if dark else "4A505C")
  for name,(ad,al) in acc.items():
    a=h(ad if dark else al); lum=L(a); s=0.7 if (lum>0.72 or lum<0.06) else 1
    for t in (0,0.5,1):
      k=(mix(.12,.28,t) if dark else mix(.08,.24,t))*s; al_=mix(.72,.95,t) if dark else mix(.70,.94,t)
      surf=lerp(card,a,k); comp=lerp(bg,surf,al_)
      for nm,c,need in (("text",text,4.5),("sec",sec,4.5)):
        v=cr(c,comp)
        if v<need: print("FAIL", "dark" if dark else "light", name, t, nm, round(v,2))
        key=("dark" if dark else "light",nm); worst[key]=min(worst.get(key,99),v)
print({k:round(v,2) for k,v in worst.items()})
